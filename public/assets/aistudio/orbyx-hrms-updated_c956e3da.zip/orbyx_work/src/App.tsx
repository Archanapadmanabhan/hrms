import React, { useState } from 'react';
import { AuthProvider, useAuth } from './services/authContext';
import { Sidebar, NavTab } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { DashboardHub } from './components/dashboard/DashboardHub';
import { EmployeeDirectory } from './components/employees/EmployeeDirectory';
import { LeaveManagement } from './components/leave/LeaveManagement';
import { PayrollDashboard } from './components/payroll/PayrollDashboard';
import { ExpenseManagement } from './components/expenses/ExpenseManagement';
import { AssetManagement } from './components/assets/AssetManagement';
import { AttendanceManagement } from './components/attendance/AttendanceManagement';
import { ReportsHub } from './components/reports/ReportsHub';
import { CompanySettings } from './components/settings/CompanySettings';
import { OrganizationSetup } from './components/organization/OrganizationSetup';
import { ClientManagement } from './components/clients/ClientManagement';
import { ApplyLeaveModal } from './components/leave/ApplyLeaveModal';
import { NewExpenseModal } from './components/expenses/NewExpenseModal';

function MainApp() {
  const [currentTab, setCurrentTab] = useState<NavTab>('dashboard');
  const [isApplyLeaveOpen, setIsApplyLeaveOpen] = useState(false);
  const [isSubmitExpenseOpen, setIsSubmitExpenseOpen] = useState(false);

  const renderContent = () => {
    switch (currentTab) {
      case 'dashboard':
        return (
          <DashboardHub
            onNavigate={(tab) => setCurrentTab(tab)}
            onOpenApplyLeave={() => setIsApplyLeaveOpen(true)}
            onOpenSubmitExpense={() => setIsSubmitExpenseOpen(true)}
          />
        );
      case 'organization':
        return <OrganizationSetup />;
      case 'employees':
        return <EmployeeDirectory />;
      case 'clients':
        return <ClientManagement />;
      case 'leave':
        return <LeaveManagement />;
      case 'payroll':
        return <PayrollDashboard />;
      case 'expenses':
        return <ExpenseManagement />;
      case 'assets':
        return <AssetManagement />;
      case 'attendance':
        return <AttendanceManagement />;
      case 'reports':
        return <ReportsHub />;
      case 'settings':
        return <CompanySettings />;
      default:
        return (
          <DashboardHub
            onNavigate={(tab) => setCurrentTab(tab)}
            onOpenApplyLeave={() => setIsApplyLeaveOpen(true)}
            onOpenSubmitExpense={() => setIsSubmitExpenseOpen(true)}
          />
        );
    }
  };

  return (
    <div className="flex h-screen bg-slate-100 overflow-hidden font-sans text-slate-800 antialiased">
      {/* Sidebar Navigation */}
      <Sidebar currentTab={currentTab} onSelectTab={(tab) => setCurrentTab(tab)} />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Header */}
        <Header currentTab={currentTab} />

        {/* Viewport Content */}
        <main className="flex-1 overflow-y-auto p-6 md:p-8">
          <div className="max-w-7xl mx-auto">{renderContent()}</div>
        </main>
      </div>

      {/* Global Modals for Quick Action Triggers */}
      <ApplyLeaveModal
        isOpen={isApplyLeaveOpen}
        onClose={() => setIsApplyLeaveOpen(false)}
      />
      <NewExpenseModal
        isOpen={isSubmitExpenseOpen}
        onClose={() => setIsSubmitExpenseOpen(false)}
      />
    </div>
  );
}

export function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}

export default App;
