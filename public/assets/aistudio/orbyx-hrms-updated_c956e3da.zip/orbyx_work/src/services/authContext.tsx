import React, { createContext, useContext, useState, useEffect } from 'react';
import { CurrentUser, UserRole, Employee } from '../types/hrms';
import { personaUsers } from '../db/initialData';
import { db, initDatabase } from '../db/storage';

interface AuthContextType {
  currentUser: CurrentUser;
  currentEmployee?: Employee;
  switchPersona: (userId: string) => void;
  allPersonas: CurrentUser[];
  canAccessModule: (module: 'hr' | 'organization' | 'clients' | 'leave' | 'payroll' | 'expenses' | 'assets' | 'attendance' | 'reports' | 'settings') => boolean;
  canViewConfidentialSalary: (targetEmployeeId: string) => boolean;
  canManageOrganization: () => boolean;
  canProcessPayroll: () => boolean;
  canApproveRequestFor: (requesterEmployeeId: string) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<CurrentUser>(() => {
    initDatabase();
    const savedUserId = localStorage.getItem('orbyx_hrms_current_user_id');
    const found = personaUsers.find((p) => p.id === savedUserId);
    return found || personaUsers[0]; // Default to Anamika (HR Admin)
  });

  const [currentEmployee, setCurrentEmployee] = useState<Employee | undefined>(() => {
    return db.getEmployeeById(currentUser.employeeId);
  });

  useEffect(() => {
    const emp = db.getEmployeeById(currentUser.employeeId);
    setCurrentEmployee(emp);
  }, [currentUser]);

  const switchPersona = (userId: string) => {
    const target = personaUsers.find((p) => p.id === userId);
    if (target) {
      setCurrentUser(target);
      localStorage.setItem('orbyx_hrms_current_user_id', target.id);
      db.logAudit({
        actorUserId: target.id,
        actorName: target.name,
        actorRole: target.role,
        action: 'LOGIN',
        module: 'SYSTEM',
        entityId: target.id,
        entityName: target.name,
        description: `Switched active session to persona ${target.name} (${target.role})`
      });
    }
  };

  // Module Access checks
  const canAccessModule = (module: 'hr' | 'organization' | 'clients' | 'leave' | 'payroll' | 'expenses' | 'assets' | 'attendance' | 'reports' | 'settings'): boolean => {
    if (currentUser.role === 'hr_admin') return true;

    if (module === 'settings') return false;
    if (module === 'organization') return currentUser.role === 'hr_admin';
    if (module === 'clients') return true; // Employees see only their own client assignments in the module.

    if (module === 'reports') {
      // Organization-wide Reports and Analytics is strictly for HR Admin and Senior Management (Dr. Selvakumar)
      // Blocked for regular employees and reporting managers (Krishnaraj) per Section 7.2 and 7.3
      return currentUser.role === 'senior_manager';
    }

    if (currentUser.role === 'senior_manager') {
      return true;
    }

    if (currentUser.role === 'reporting_manager') {
      return true;
    }

    if (currentUser.role === 'employee') {
      // Employees access self-service views and directory
      return true;
    }

    return false;
  };

  // Field-level access: Salary, Bank info
  const canViewConfidentialSalary = (targetEmployeeId: string): boolean => {
    if (currentUser.role === 'hr_admin') return true;
    // Employees and managers can view only their own salary
    return currentUser.employeeId === targetEmployeeId;
  };

  const canManageOrganization = (): boolean => {
    return currentUser.role === 'hr_admin';
  };

  const canProcessPayroll = (): boolean => {
    return currentUser.role === 'hr_admin';
  };

  // Hierarchy check: Manager can approve if employee reports to them. Self-approval strictly forbidden!
  const canApproveRequestFor = (requesterEmployeeId: string): boolean => {
    if (requesterEmployeeId === currentUser.employeeId) return false; // Self-approval prohibited
    if (currentUser.role === 'hr_admin') return true;
    const requester = db.getEmployeeById(requesterEmployeeId);
    if (!requester) return false;
    // Direct report check
    return requester.reportingManagerId === currentUser.employeeId;
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        currentEmployee,
        switchPersona,
        allPersonas: personaUsers,
        canAccessModule,
        canViewConfidentialSalary,
        canManageOrganization,
        canProcessPayroll,
        canApproveRequestFor
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
