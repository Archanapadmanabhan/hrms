import {
  Employee,
  LeaveApplication,
  LeaveBalance,
  AttendanceRecord,
  AttendanceCorrectionRequest,
  ExpenseClaim,
  Asset,
  PayrollRun,
  PayrollLineItem,
  AuditLog
} from '../types/hrms';
import { db } from '../db/storage';

export const hrmsService = {
  // ---------------- MODULE 1: EMPLOYEES ----------------
  generateNextEmployeeId(): string {
    const employees = db.getEmployees();
    const numbers = employees
      .map((e) => {
        const match = e.id.match(/\d+/);
        return match ? parseInt(match[0], 10) : 0;
      })
      .filter((n) => !isNaN(n));
    const max = numbers.length > 0 ? Math.max(...numbers) : 0;
    return `EMP-${String(max + 1).padStart(3, '0')}`;
  },

  createEmployee(employeeData: Omit<Employee, 'id' | 'createdAt' | 'updatedAt'>, actorUserId: string, actorName: string): Employee {
    const id = this.generateNextEmployeeId();
    const now = new Date().toISOString();
    const newEmp: Employee = {
      ...employeeData,
      id,
      createdAt: now,
      updatedAt: now
    };
    db.saveEmployee(newEmp);

    db.logAudit({
      actorUserId,
      actorName,
      actorRole: 'hr_admin',
      action: 'CREATE',
      module: 'EMPLOYEE',
      entityId: id,
      entityName: `${newEmp.firstName} ${newEmp.lastName}`,
      description: `Created new employee profile ${id} in ${newEmp.departmentId}`
    });

    db.addNotification({
      targetUserId: 'all',
      title: 'New Team Member',
      message: `${newEmp.firstName} ${newEmp.lastName} has joined Orbyx!`,
      module: 'employee'
    });

    return newEmp;
  },

  updateEmployee(employee: Employee, actorUserId: string, actorName: string): void {
    const updated = { ...employee, updatedAt: new Date().toISOString() };
    db.saveEmployee(updated);

    db.logAudit({
      actorUserId,
      actorName,
      actorRole: 'hr_admin',
      action: 'UPDATE',
      module: 'EMPLOYEE',
      entityId: employee.id,
      entityName: `${employee.firstName} ${employee.lastName}`,
      description: `Updated employee profile attributes for ${employee.id}`
    });
  },

  // ---------------- MODULE 2: LEAVE ----------------
  calculateWorkingDays(startDateStr: string, endDateStr: string, isHalfDay: boolean): number {
    if (isHalfDay) return 0.5;

    const start = new Date(startDateStr);
    const end = new Date(endDateStr);
    if (start > end) return 0;

    const holidays = db.getHolidays().map((h) => h.date);
    let count = 0;
    const current = new Date(start);

    while (current <= end) {
      const dayOfWeek = current.getDay(); // 0 is Sunday, 6 is Saturday
      const dateString = current.toISOString().split('T')[0];
      const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
      const isHoliday = holidays.includes(dateString);

      if (!isWeekend && !isHoliday) {
        count++;
      }
      current.setDate(current.getDate() + 1);
    }

    return Math.max(count, 1); // Minimum 1 working day if within range
  },

  getLeaveBalance(employeeId: string, leaveTypeId: string): LeaveBalance {
    const leaveType = db.getLeaveTypes().find((lt) => lt.id === leaveTypeId);
    const totalEntitled = leaveType ? leaveType.annualEntitlement : 0;

    const apps = db.getLeaveApplications().filter(
      (a) => a.employeeId === employeeId && a.leaveTypeId === leaveTypeId
    );

    let taken = 0;
    let pending = 0;

    apps.forEach((a) => {
      if (a.status === 'Approved') taken += a.totalDays;
      else if (a.status === 'Pending Approval') pending += a.totalDays;
    });

    return {
      employeeId,
      leaveTypeId,
      totalEntitled,
      taken,
      pending,
      remaining: Math.max(0, totalEntitled - taken - pending)
    };
  },

  applyLeave(
    data: {
      employeeId: string;
      leaveTypeId: string;
      startDate: string;
      endDate: string;
      isHalfDay: boolean;
      halfDayPeriod?: 'First Half' | 'Second Half';
      reason: string;
      attachmentName?: string;
    },
    actorUserId: string,
    actorName: string
  ): { success: boolean; error?: string; application?: LeaveApplication } {
    const emp = db.getEmployeeById(data.employeeId);
    if (!emp) return { success: false, error: 'Employee not found' };

    const leaveType = db.getLeaveTypes().find((l) => l.id === data.leaveTypeId);
    if (!leaveType) return { success: false, error: 'Invalid leave type' };

    // Check overlapping approved/pending leaves
    const existingApps = db.getLeaveApplications().filter(
      (a) =>
        a.employeeId === data.employeeId &&
        (a.status === 'Approved' || a.status === 'Pending Approval')
    );

    for (const app of existingApps) {
      if (data.startDate <= app.endDate && data.endDate >= app.startDate) {
        return {
          success: false,
          error: `Dates overlap with existing application (${app.startDate} to ${app.endDate}, status: ${app.status})`
        };
      }
    }

    const totalDays = this.calculateWorkingDays(data.startDate, data.endDate, data.isHalfDay);
    const balance = this.getLeaveBalance(data.employeeId, data.leaveTypeId);

    if (leaveType.isPaid && !leaveType.allowNegativeBalance && totalDays > balance.remaining) {
      return {
        success: false,
        error: `Insufficient leave balance. Requested ${totalDays} days, but only ${balance.remaining} days available.`
      };
    }

    const approverId = emp.reportingManagerId || 'EMP-001'; // Fallback to HR lead
    const approver = db.getEmployeeById(approverId);

    const newApp: LeaveApplication = {
      id: `LV-APP-${Date.now()}`,
      employeeId: data.employeeId,
      leaveTypeId: data.leaveTypeId,
      startDate: data.startDate,
      endDate: data.endDate,
      isHalfDay: data.isHalfDay,
      halfDayPeriod: data.halfDayPeriod,
      totalDays,
      reason: data.reason,
      attachmentName: data.attachmentName,
      status: 'Pending Approval',
      approverId,
      appliedAt: new Date().toISOString()
    };

    db.saveLeaveApplication(newApp);

    // Notify Approver
    if (approver) {
      db.addNotification({
        targetUserId: approver.userId,
        title: 'Leave Approval Requested',
        message: `${emp.firstName} ${emp.lastName} requested ${totalDays} day(s) of ${leaveType.name} from ${data.startDate}`,
        module: 'leave'
      });
    }

    db.logAudit({
      actorUserId,
      actorName,
      actorRole: 'employee',
      action: 'CREATE',
      module: 'LEAVE',
      entityId: newApp.id,
      entityName: `${emp.firstName} ${emp.lastName}`,
      description: `Applied for ${totalDays} day(s) of ${leaveType.name} (${data.startDate} to ${data.endDate})`
    });

    return { success: true, application: newApp };
  },

  decideLeave(
    applicationId: string,
    decision: 'Approved' | 'Rejected',
    comments: string,
    actorUserId: string,
    actorName: string
  ): { success: boolean; error?: string } {
    const apps = db.getLeaveApplications();
    const app = apps.find((a) => a.id === applicationId);
    if (!app) return { success: false, error: 'Application not found' };

    // Prevent prohibited self-approval per Section 9.3
    const actorEmployee = db.getEmployeeByUserId(actorUserId);
    if (actorEmployee && actorEmployee.id === app.employeeId) {
      return { success: false, error: 'Unauthorized: Self-approval is strictly prohibited by organizational policy.' };
    }

    app.status = decision;
    app.approvalComments = comments;
    app.decidedAt = new Date().toISOString();
    db.saveLeaveApplication(app);

    const emp = db.getEmployeeById(app.employeeId);
    if (emp) {
      db.addNotification({
        targetUserId: emp.userId,
        title: `Leave Application ${decision}`,
        message: `Your leave request for ${app.startDate} has been ${decision.toLowerCase()} by ${actorName}.`,
        module: 'leave'
      });
    }

    db.logAudit({
      actorUserId,
      actorName,
      actorRole: 'senior_manager',
      action: decision === 'Approved' ? 'APPROVE' : 'REJECT',
      module: 'LEAVE',
      entityId: app.id,
      entityName: `${emp ? emp.firstName + ' ' + emp.lastName : app.employeeId}`,
      description: `${decision} leave request (${app.totalDays} days) with note: "${comments || 'No comments'}"`
    });
  },

  // ---------------- MODULE 4: EXPENSES ----------------
  submitExpenseClaim(
    data: {
      employeeId: string;
      categoryId: string;
      title: string;
      amount: number;
      currency: string;
      expenseDate: string;
      businessPurpose: string;
      receiptFileName?: string;
    },
    actorUserId: string,
    actorName: string
  ): { success: boolean; error?: string; claim?: ExpenseClaim } {
    const emp = db.getEmployeeById(data.employeeId);
    if (!emp) return { success: false, error: 'Employee not found' };

    const category = db.getExpenseCategories().find((c) => c.id === data.categoryId);
    if (!category) return { success: false, error: 'Invalid expense category' };

    if (category.maxLimitPerClaim && data.amount > category.maxLimitPerClaim) {
      return {
        success: false,
        error: `Amount exceeds maximum limit of ₹${category.maxLimitPerClaim.toLocaleString()} for category ${category.name}`
      };
    }

    // Check duplicate claim warning
    const duplicates = db.getExpenseClaims().filter(
      (c) =>
        c.employeeId === data.employeeId &&
        c.expenseDate === data.expenseDate &&
        c.amount === data.amount &&
        c.categoryId === data.categoryId &&
        c.status !== 'Rejected'
    );

    if (duplicates.length > 0) {
      return {
        success: false,
        error: `A matching expense claim (${duplicates[0].claimNumber}) with the same amount and date is already pending or approved.`
      };
    }

    const approverId = emp.reportingManagerId || 'EMP-001';
    const approver = db.getEmployeeById(approverId);
    const claimNumber = `EXP-2026-${String(db.getExpenseClaims().length + 1).padStart(3, '0')}`;

    const newClaim: ExpenseClaim = {
      id: `EXP-ID-${Date.now()}`,
      claimNumber,
      employeeId: data.employeeId,
      categoryId: data.categoryId,
      title: data.title,
      amount: data.amount,
      currency: data.currency || 'INR',
      expenseDate: data.expenseDate,
      businessPurpose: data.businessPurpose,
      receiptFileName: data.receiptFileName,
      status: 'Pending Manager Approval',
      approverId,
      submittedAt: new Date().toISOString()
    };

    db.saveExpenseClaim(newClaim);

    if (approver) {
      db.addNotification({
        targetUserId: approver.userId,
        title: 'Expense Claim Submitted',
        message: `${emp.firstName} ${emp.lastName} submitted claim ${claimNumber} (₹${data.amount.toLocaleString()}) for approval.`,
        module: 'expense'
      });
    }

    db.logAudit({
      actorUserId,
      actorName,
      actorRole: 'employee',
      action: 'CREATE',
      module: 'EXPENSE',
      entityId: newClaim.id,
      entityName: claimNumber,
      description: `Submitted claim for ₹${data.amount} (${category.name})`
    });

    return { success: true, claim: newClaim };
  },

  decideExpenseClaim(
    claimId: string,
    decision: 'Approved' | 'Rejected',
    comments: string,
    actorUserId: string,
    actorName: string
  ): { success: boolean; error?: string } {
    const claims = db.getExpenseClaims();
    const claim = claims.find((c) => c.id === claimId);
    if (!claim) return { success: false, error: 'Claim not found' };

    // Prevent prohibited self-approval per Section 9.3
    const actorEmployee = db.getEmployeeByUserId(actorUserId);
    if (actorEmployee && actorEmployee.id === claim.employeeId) {
      return { success: false, error: 'Unauthorized: Self-approval is strictly prohibited by organizational policy.' };
    }

    claim.status = decision === 'Approved' ? 'Pending Reimbursement' : 'Rejected';
    claim.approvalComments = comments;
    claim.decidedAt = new Date().toISOString();
    db.saveExpenseClaim(claim);

    const emp = db.getEmployeeById(claim.employeeId);
    if (emp) {
      db.addNotification({
        targetUserId: emp.userId,
        title: `Expense Claim ${decision}`,
        message: `Your claim ${claim.claimNumber} (₹${claim.amount.toLocaleString()}) was ${decision.toLowerCase()}.`,
        module: 'expense'
      });
    }

    db.logAudit({
      actorUserId,
      actorName,
      actorRole: 'senior_manager',
      action: decision === 'Approved' ? 'APPROVE' : 'REJECT',
      module: 'EXPENSE',
      entityId: claim.id,
      entityName: claim.claimNumber,
      description: `${decision} expense claim for ₹${claim.amount}. Note: "${comments || 'None'}"`
    });
  },

  reimburseExpenseClaim(
    claimId: string,
    paymentReference: string,
    actorUserId: string,
    actorName: string
  ): void {
    const claims = db.getExpenseClaims();
    const claim = claims.find((c) => c.id === claimId);
    if (!claim) return;

    claim.status = 'Reimbursed';
    claim.reimbursementReference = paymentReference;
    claim.reimbursedAt = new Date().toISOString();
    db.saveExpenseClaim(claim);

    const emp = db.getEmployeeById(claim.employeeId);
    if (emp) {
      db.addNotification({
        targetUserId: emp.userId,
        title: 'Expense Claim Reimbursed',
        message: `Reimbursement for claim ${claim.claimNumber} (₹${claim.amount.toLocaleString()}) processed via Ref #${paymentReference}.`,
        module: 'expense'
      });
    }

    db.logAudit({
      actorUserId,
      actorName,
      actorRole: 'hr_admin',
      action: 'REIMBURSE',
      module: 'EXPENSE',
      entityId: claim.id,
      entityName: claim.claimNumber,
      description: `Reimbursed ₹${claim.amount} via reference ${paymentReference}`
    });
  },

  // ---------------- MODULE 5: ASSETS ----------------
  allocateAsset(
    assetId: string,
    employeeId: string,
    condition: any,
    actorUserId: string,
    actorName: string
  ): { success: boolean; error?: string } {
    const asset = db.getAssetById(assetId);
    if (!asset) return { success: false, error: 'Asset not found' };
    if (asset.status === 'Allocated') {
      return { success: false, error: `Asset is already allocated to employee ${asset.currentEmployeeId}` };
    }

    const emp = db.getEmployeeById(employeeId);
    if (!emp) return { success: false, error: 'Employee not found' };

    asset.status = 'Allocated';
    asset.currentEmployeeId = employeeId;
    asset.allocatedDate = new Date().toISOString().split('T')[0];
    asset.condition = condition;
    asset.acknowledgedByEmployee = false;
    db.saveAsset(asset);

    db.addNotification({
      targetUserId: emp.userId,
      title: 'New Asset Assigned',
      message: `${asset.name} (${asset.assetTag}) has been allocated to you. Please acknowledge receipt.`,
      module: 'asset'
    });

    db.logAudit({
      actorUserId,
      actorName,
      actorRole: 'hr_admin',
      action: 'ALLOCATE',
      module: 'ASSET',
      entityId: asset.id,
      entityName: asset.assetTag,
      description: `Allocated ${asset.name} to ${emp.firstName} ${emp.lastName}`
    });

    return { success: true };
  },

  acknowledgeAssetReceipt(assetId: string, actorUserId: string, actorName: string): void {
    const asset = db.getAssetById(assetId);
    if (!asset) return;

    asset.acknowledgedByEmployee = true;
    asset.acknowledgedAt = new Date().toISOString();
    db.saveAsset(asset);

    db.logAudit({
      actorUserId,
      actorName,
      actorRole: 'employee',
      action: 'UPDATE',
      module: 'ASSET',
      entityId: asset.id,
      entityName: asset.assetTag,
      description: `Employee acknowledged receipt of asset ${asset.assetTag}`
    });
  },

  returnAsset(
    assetId: string,
    returnCondition: any,
    notes: string,
    actorUserId: string,
    actorName: string
  ): void {
    const asset = db.getAssetById(assetId);
    if (!asset) return;

    const previousEmpId = asset.currentEmployeeId;
    asset.status = 'Available';
    asset.condition = returnCondition;
    asset.currentEmployeeId = undefined;
    asset.allocatedDate = undefined;
    asset.acknowledgedByEmployee = false;
    asset.notes = notes ? `${asset.notes || ''} | Returned: ${notes}` : asset.notes;
    db.saveAsset(asset);

    db.logAudit({
      actorUserId,
      actorName,
      actorRole: 'hr_admin',
      action: 'UPDATE',
      module: 'ASSET',
      entityId: asset.id,
      entityName: asset.assetTag,
      description: `Asset returned from ${previousEmpId || 'employee'} in condition: ${returnCondition}`
    });
  },

  // ---------------- MODULE 6: SHIFTS & ATTENDANCE ----------------
  punchAttendance(
    employeeId: string,
    punchType: 'check-in' | 'check-out',
    actorUserId: string,
    actorName: string
  ): { success: boolean; record: AttendanceRecord } {
    const emp = db.getEmployeeById(employeeId);
    const today = new Date().toISOString().split('T')[0];
    const nowHours = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
    const shift = db.getShifts().find((s) => s.id === (emp?.shiftId || 'SHIFT-GEN')) || db.getShifts()[0];

    let record = db.getAttendanceRecords().find(
      (r) => r.employeeId === employeeId && r.date === today
    );

    if (punchType === 'check-in') {
      if (!record) {
        // Compare with shift start + grace
        const [shiftH, shiftM] = shift.startTime.split(':').map(Number);
        const shiftGraceMinutes = shiftH * 60 + shiftM + shift.gracePeriodMinutes;
        const [nowH, nowM] = nowHours.split(':').map(Number);
        const currentMinutes = nowH * 60 + nowM;

        const isLate = currentMinutes > shiftGraceMinutes;
        const lateMinutes = isLate ? currentMinutes - (shiftH * 60 + shiftM) : 0;

        record = {
          id: `ATT-${today.replace(/-/g, '')}-${employeeId}`,
          employeeId,
          date: today,
          shiftId: shift.id,
          checkInTime: nowHours,
          totalHoursWorked: 0,
          regularHours: 0,
          overtimeHours: 0,
          status: isLate ? 'Late' : 'Present',
          isLate,
          isEarlyDeparture: false,
          lateMinutes,
          source: 'Web Punch'
        };
      } else {
        record.checkInTime = nowHours;
      }
    } else {
      // Check-out
      if (!record) {
        record = {
          id: `ATT-${today.replace(/-/g, '')}-${employeeId}`,
          employeeId,
          date: today,
          shiftId: shift.id,
          checkInTime: '09:30', // Default if punch out without check in
          checkOutTime: nowHours,
          totalHoursWorked: 8.0,
          regularHours: 8.0,
          overtimeHours: 0,
          status: 'Present',
          isLate: false,
          isEarlyDeparture: false,
          lateMinutes: 0,
          source: 'Web Punch'
        };
      } else {
        record.checkOutTime = nowHours;
        if (record.checkInTime) {
          const [inH, inM] = record.checkInTime.split(':').map(Number);
          const [outH, outM] = nowHours.split(':').map(Number);
          const totalMinutes = Math.max(0, outH * 60 + outM - (inH * 60 + inM) - shift.breakDurationMinutes);
          const hours = Number((totalMinutes / 60).toFixed(2));
          record.totalHoursWorked = hours;
          record.regularHours = Math.min(hours, 8.0);
          record.overtimeHours = Math.max(0, Number((hours - 8.0).toFixed(2)));
        }
      }
    }

    db.saveAttendanceRecord(record);

    db.logAudit({
      actorUserId,
      actorName,
      actorRole: 'employee',
      action: 'UPDATE',
      module: 'ATTENDANCE',
      entityId: record.id,
      entityName: `${emp?.firstName || employeeId} (${punchType})`,
      description: `Web punch ${punchType} recorded at ${nowHours}`
    });

    return { success: true, record };
  },

  submitAttendanceCorrection(
    data: {
      employeeId: string;
      date: string;
      requestedCheckIn: string;
      requestedCheckOut: string;
      reason: string;
    },
    actorUserId: string,
    actorName: string
  ): AttendanceCorrectionRequest {
    const emp = db.getEmployeeById(data.employeeId);
    const approverId = emp?.reportingManagerId || 'EMP-001';

    const req: AttendanceCorrectionRequest = {
      id: `CORR-${Date.now()}`,
      employeeId: data.employeeId,
      date: data.date,
      requestedCheckIn: data.requestedCheckIn,
      requestedCheckOut: data.requestedCheckOut,
      reason: data.reason,
      status: 'Pending',
      approverId,
      submittedAt: new Date().toISOString()
    };

    db.saveCorrectionRequest(req);

    const approver = db.getEmployeeById(approverId);
    if (approver) {
      db.addNotification({
        targetUserId: approver.userId,
        title: 'Attendance Correction Request',
        message: `${emp?.firstName} ${emp?.lastName} requested attendance correction for ${data.date}.`,
        module: 'attendance'
      });
    }

    db.logAudit({
      actorUserId,
      actorName,
      actorRole: 'employee',
      action: 'CREATE',
      module: 'ATTENDANCE',
      entityId: req.id,
      entityName: `${emp?.firstName || data.employeeId}`,
      description: `Requested attendance correction for ${data.date}: ${data.reason}`
    });

    return req;
  },

  decideAttendanceCorrection(
    requestId: string,
    decision: 'Approved' | 'Rejected',
    comments: string,
    actorUserId: string,
    actorName: string
  ): { success: boolean; error?: string } {
    const requests = db.getCorrectionRequests();
    const req = requests.find((r) => r.id === requestId);
    if (!req) return { success: false, error: 'Request not found' };

    // Prevent prohibited self-approval per Section 9.3
    const actorEmployee = db.getEmployeeByUserId(actorUserId);
    if (actorEmployee && actorEmployee.id === req.employeeId) {
      return { success: false, error: 'Unauthorized: Self-approval is strictly prohibited by organizational policy.' };
    }

    req.status = decision;
    req.approverComments = comments;
    req.decidedAt = new Date().toISOString();
    db.saveCorrectionRequest(req);

    if (decision === 'Approved') {
      // Update or create Attendance Record
      const existing = db.getAttendanceRecords().find(
        (r) => r.employeeId === req.employeeId && r.date === req.date
      );

      const record: AttendanceRecord = {
        id: existing?.id || `ATT-${req.date.replace(/-/g, '')}-${req.employeeId}`,
        employeeId: req.employeeId,
        date: req.date,
        shiftId: existing?.shiftId || 'SHIFT-GEN',
        checkInTime: req.requestedCheckIn,
        checkOutTime: req.requestedCheckOut,
        totalHoursWorked: 8.0,
        regularHours: 8.0,
        overtimeHours: 0,
        status: 'Present',
        isLate: false,
        isEarlyDeparture: false,
        lateMinutes: 0,
        source: 'Manual HR Entry',
        notes: `Corrected via approved request: ${req.reason}`
      };
      db.saveAttendanceRecord(record);
    }

    const emp = db.getEmployeeById(req.employeeId);
    if (emp) {
      db.addNotification({
        targetUserId: emp.userId,
        title: `Attendance Correction ${decision}`,
        message: `Your attendance correction for ${req.date} was ${decision.toLowerCase()}.`,
        module: 'attendance'
      });
    }

    db.logAudit({
      actorUserId,
      actorName,
      actorRole: 'senior_manager',
      action: decision === 'Approved' ? 'APPROVE' : 'REJECT',
      module: 'ATTENDANCE',
      entityId: req.id,
      entityName: req.employeeId,
      description: `${decision} attendance correction for ${req.date}. Note: "${comments || 'None'}"`
    });
  },

  // ---------------- MODULE 3: PAYROLL ----------------
  generatePayrollPreview(
    month: number,
    year: number,
    actorUserId: string,
    actorName: string
  ): { run: PayrollRun; items: PayrollLineItem[] } {
    const periodLabel = new Date(year, month - 1, 1).toLocaleString('default', {
      month: 'long',
      year: 'numeric'
    });
    const runId = `PR-${year}-${String(month).padStart(2, '0')}`;
    const daysInMonth = new Date(year, month, 0).getDate();
    const startDate = `${year}-${String(month).padStart(2, '0')}-01`;
    const endDate = `${year}-${String(month).padStart(2, '0')}-${daysInMonth}`;

    const activeEmployees = db.getEmployees().filter((e) => e.status === 'Active' || e.status === 'Probation');
    const departments = db.getDepartments();
    const designations = db.getDesignations();
    const structures = db.getSalaryStructures();

    const items: PayrollLineItem[] = [];
    let runTotalGross = 0;
    let runTotalDeductions = 0;
    let runTotalNet = 0;

    activeEmployees.forEach((emp) => {
      const dept = departments.find((d) => d.id === emp.departmentId)?.name || 'General';
      const desig = designations.find((d) => d.id === emp.designationId)?.title || 'Associate';
      const struct = structures.find((s) => s.id === emp.salaryStructureId) || structures[1];

      // Pull unpaid leaves (LOP) in this month
      const unpaidApps = db.getLeaveApplications().filter(
        (a) =>
          a.employeeId === emp.id &&
          a.status === 'Approved' &&
          a.leaveTypeId === 'LT-LOP' &&
          a.startDate.startsWith(`${year}-${String(month).padStart(2, '0')}`)
      );
      const unpaidDays = unpaidApps.reduce((acc, curr) => acc + curr.totalDays, 0);

      const workingDays = 30; // standard commercial monthly payroll denominator
      const payableDays = Math.max(0, workingDays - unpaidDays);

      // Structure components
      const basicItem = struct.items.find((i) => i.componentCode === 'BASIC');
      const hraItem = struct.items.find((i) => i.componentCode === 'HRA');
      const splItem = struct.items.find((i) => i.componentCode === 'SPL_ALLW');

      const fullMonthlyGross = struct.grossMonthly;
      const perDayGross = fullMonthlyGross / workingDays;
      const lopDeduction = Math.round(unpaidDays * perDayGross);

      const grossEarnings = Math.max(0, fullMonthlyGross - lopDeduction);
      const basicEarnings = Math.round((basicItem ? basicItem.amountMonthly : fullMonthlyGross * 0.5) * (payableDays / workingDays));
      const hraEarnings = Math.round((hraItem ? hraItem.amountMonthly : fullMonthlyGross * 0.25) * (payableDays / workingDays));
      const specialAllowanceEarnings = Math.max(0, grossEarnings - basicEarnings - hraEarnings);

      // Statutory deductions
      // PF: 12% of basic, capped at 1800 or full
      const pfEmployee = Math.round(basicEarnings * 0.12);
      // ESI: 0.75% of gross if gross <= 21000
      const esiEmployee = grossEarnings <= 21000 ? Math.round(grossEarnings * 0.0075) : 0;
      // PT: ₹200 standard monthly slab in Karnataka/Maharashtra
      const professionalTax = 200;
      // TDS: from structure or estimate
      const tdsItem = struct.items.find((i) => i.componentCode === 'TDS');
      const tdsWithholding = tdsItem ? tdsItem.amountMonthly : 0;

      const totalDeductions = pfEmployee + esiEmployee + professionalTax + tdsWithholding;
      const netPayable = Math.max(0, grossEarnings - totalDeductions);

      // Employer cost
      const pfEmployer = pfEmployee;
      const esiEmployer = grossEarnings <= 21000 ? Math.round(grossEarnings * 0.0325) : 0;
      const totalEmployerCost = grossEarnings + pfEmployer + esiEmployer;

      runTotalGross += grossEarnings;
      runTotalDeductions += totalDeductions;
      runTotalNet += netPayable;

      items.push({
        id: `ITEM-${runId}-${emp.id}`,
        payrollRunId: runId,
        employeeId: emp.id,
        employeeName: `${emp.firstName} ${emp.lastName}`,
        departmentName: dept,
        designationTitle: desig,
        bankAccountNumber: emp.bankDetails.accountNumber,
        panNumber: emp.panOrTaxNumber,
        workingDaysInMonth: workingDays,
        daysPresent: payableDays,
        paidLeaves: 0,
        unpaidLeaves: unpaidDays,
        payableDays,
        basicEarnings,
        hraEarnings,
        specialAllowanceEarnings,
        grossEarnings,
        pfEmployee,
        esiEmployee,
        professionalTax,
        tdsWithholding,
        unpaidLeaveDeduction: lopDeduction,
        otherDeductions: 0,
        totalDeductions,
        netPayable,
        pfEmployer,
        esiEmployer,
        totalEmployerCost,
        status: 'Calculated'
      });
    });

    const run: PayrollRun = {
      id: runId,
      month,
      year,
      periodLabel,
      startDate,
      endDate,
      totalEmployees: items.length,
      totalGrossPay: runTotalGross,
      totalDeductions: runTotalDeductions,
      totalNetPay: runTotalNet,
      status: 'Preview',
      processedBy: actorName
    };

    return { run, items };
  },

  finalizePayrollRun(
    run: PayrollRun,
    items: PayrollLineItem[],
    actorUserId: string,
    actorName: string
  ): void {
    const finalizedRun: PayrollRun = {
      ...run,
      status: 'Finalized',
      approvedBy: actorName,
      finalizedAt: new Date().toISOString()
    };

    const finalizedItems = items.map((i) => ({
      ...i,
      status: 'Finalized' as const
    }));

    db.savePayrollRun(finalizedRun);
    db.savePayrollLineItems(finalizedItems);

    // Broadcast notification to all employees that payslips are generated
    finalizedItems.forEach((item) => {
      const emp = db.getEmployeeById(item.employeeId);
      if (emp) {
        db.addNotification({
          targetUserId: emp.userId,
          title: `Payslip Available (${run.periodLabel})`,
          message: `Your payslip for ${run.periodLabel} is ready. Net Pay: ₹${item.netPayable.toLocaleString()}.`,
          module: 'payroll'
        });
      }
    });

    db.logAudit({
      actorUserId,
      actorName,
      actorRole: 'hr_admin',
      action: 'FINALIZE',
      module: 'PAYROLL',
      entityId: finalizedRun.id,
      entityName: finalizedRun.periodLabel,
      description: `Finalized and locked payroll for ${finalizedRun.periodLabel} (Net: ₹${finalizedRun.totalNetPay.toLocaleString()})`
    });
  },

  recordPayrollDisbursement(
    runId: string,
    paymentReference: string,
    actorUserId: string,
    actorName: string
  ): void {
    const run = db.getPayrollRuns().find((r) => r.id === runId);
    if (!run) return;

    run.status = 'Paid';
    run.paymentReference = paymentReference;
    run.paymentDate = new Date().toISOString().split('T')[0];
    db.savePayrollRun(run);

    const items = db.getPayrollLineItems(runId).map((i) => ({
      ...i,
      status: 'Paid' as const
    }));
    db.savePayrollLineItems(items);

    db.logAudit({
      actorUserId,
      actorName,
      actorRole: 'hr_admin',
      action: 'UPDATE',
      module: 'PAYROLL',
      entityId: run.id,
      entityName: run.periodLabel,
      description: `Disbursed salaries for ${run.periodLabel} via bank ref ${paymentReference}`
    });
  }
};
