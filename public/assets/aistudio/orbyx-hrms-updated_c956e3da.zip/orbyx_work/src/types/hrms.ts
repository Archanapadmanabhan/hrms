export type UserRole = 'hr_admin' | 'senior_manager' | 'reporting_manager' | 'employee';

export type EmploymentType = 'Permanent' | 'Contract' | 'Probation' | 'Intern';
export type EmploymentStatus = 'Active' | 'On Leave' | 'Probation' | 'Notice Period' | 'Separated' | 'Inactive';

export interface CompanyProfile {
  id: string;
  name: string;
  legalEntity: string;
  taxId: string; // PAN / GSTIN / EIN
  pfRegistrationNumber: string;
  esiRegistrationNumber: string;
  address: string;
  city: string;
  state: string;
  country: string;
  zipCode: string;
  currency: string;
  currencySymbol: string;
  workingDaysPerWeek: number;
  standardHoursPerDay: number;
  fiscalYearStart: string; // MM-DD
}

export interface Branch {
  id: string;
  name: string;
  code: string;
  city: string;
  isHeadquarters: boolean;
}

export interface Department {
  id: string;
  name: string;
  code: string;
  headEmployeeId?: string;
  description: string;
}

export interface Designation {
  id: string;
  title: string;
  code: string;
  departmentId: string;
  level: string; // Junior, Mid, Senior, Lead, Executive
}

export interface EmployeeDocument {
  id: string;
  employeeId: string;
  title: string;
  documentType: 'ID Proof' | 'Offer Letter' | 'Degree' | 'Address Proof' | 'Tax Form' | 'Contract';
  fileName: string;
  fileSize: string;
  uploadedAt: string;
  verifiedBy?: string;
  fileUrl?: string;
}

export type Permission =
  | 'employee.profile.read_self'
  | 'employee.profile.update_self'
  | 'employee.directory.read_basic'
  | 'employee.profile.read_team'
  | 'employee.profile.read_all'
  | 'employee.profile.read_org'
  | 'employee.profile.read_sensitive'
  | 'employee.documents.read_team'
  | 'employee.documents.read_all'
  | 'employee.salary.read'
  | 'employee.bank_details.read'
  | 'employee.identity_documents.read'
  | 'employee.leave.read_team'
  | 'employee.attendance.read_team'
  | 'employee.expenses.read_team'
  | 'employee.assets.read_team'
  | 'employee.assets.read_all'
  | 'employee.assets.administer'
  | 'reports.organization.read'
  | 'leave.approve_team'
  | 'expenses.approve_team'
  | 'attendance.approve_team'
  | 'payroll.process';

export interface BasicDirectoryEmployee {
  id: string;
  firstName: string;
  lastName: string;
  officialEmail: string;
  officialPhone: string;
  avatarUrl: string;
  viewScope: 'colleague_basic';
}

export type AccessScope = 'self' | 'direct_report' | 'senior_management' | 'organization_admin' | 'colleague_basic';

export interface BankAccountDetails {
  accountNumber: string;
  bankName: string;
  ifscOrRouting: string;
  accountType: 'Savings' | 'Current';
}

export interface Employee {
  id: string; // e.g. EMP-001
  userId: string;
  firstName: string;
  lastName: string;
  email: string; // Official email
  officialEmail?: string;
  phone: string; // Official mobile number
  officialPhone?: string;
  personalEmail?: string;
  personalPhone?: string;
  avatarUrl: string;
  dateOfBirth: string;
  gender: 'Male' | 'Female' | 'Other';
  bloodGroup?: string;
  maritalStatus?: 'Single' | 'Married' | 'Other';
  address: string;
  emergencyContact: {
    name: string;
    relationship: string;
    phone: string;
  };
  // Employment
  departmentId: string;
  designationId: string;
  branchId: string;
  employmentType: EmploymentType;
  status: EmploymentStatus;
  dateOfJoining: string;
  probationEndDate?: string;
  confirmationDate?: string;
  noticePeriodDays: number;
  reportingManagerId?: string; // Reports to another Employee ID
  shiftId: string;
  // Financial & Confidential
  bankDetails: BankAccountDetails;
  panOrTaxNumber: string;
  pfUan?: string;
  esiNumber?: string;
  baseSalaryAnnual: number;
  salaryStructureId: string;
  createdAt: string;
  updatedAt: string;
}

export type ProfileViewResult = 
  | (BasicDirectoryEmployee & { viewScope: 'colleague_basic' })
  | (Employee & { viewScope: 'self' | 'direct_report' | 'organization_admin'; canViewSalary: boolean });

// --------------------- MODULE 2: LEAVE ---------------------
export type LeaveTypeCode = 'AL' | 'SL' | 'CL' | 'ML' | 'PL' | 'LOP' | 'CO';

export interface LeaveType {
  id: string;
  name: string;
  code: LeaveTypeCode;
  description: string;
  isPaid: boolean;
  annualEntitlement: number;
  carryForwardLimit: number;
  maxConsecutiveDays: number;
  allowsHalfDay: boolean;
  allowNegativeBalance: boolean;
  requiresDocumentProof: boolean;
  color: string;
}

export type LeaveApplicationStatus = 
  | 'Draft' 
  | 'Pending Approval' 
  | 'Approved' 
  | 'Rejected' 
  | 'Cancelled';

export interface LeaveApplication {
  id: string;
  employeeId: string;
  leaveTypeId: string;
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  isHalfDay: boolean;
  halfDayPeriod?: 'First Half' | 'Second Half';
  totalDays: number;
  reason: string;
  attachmentName?: string;
  status: LeaveApplicationStatus;
  approverId: string;
  approvalComments?: string;
  appliedAt: string;
  decidedAt?: string;
  isDemo?: boolean;
}

export interface LeaveBalance {
  employeeId: string;
  leaveTypeId: string;
  totalEntitled: number;
  taken: number;
  pending: number;
  remaining: number;
}

export interface Holiday {
  id: string;
  name: string;
  date: string; // YYYY-MM-DD
  isOptional: boolean;
  description?: string;
}

// --------------------- MODULE 3: PAYROLL ---------------------
export type ComponentType = 'Earning' | 'Deduction' | 'Employer_Contribution';

export interface SalaryComponent {
  id: string;
  name: string;
  code: string;
  type: ComponentType;
  isStatutory: boolean;
  isTaxable: boolean;
  calculationType: 'Fixed' | 'Percentage_Basic' | 'Percentage_CTC' | 'Formula';
  formulaOrRate?: number; // e.g. 0.50 for 50% of CTC or basic
}

export interface SalaryStructureItem {
  componentId: string;
  componentCode: string;
  componentName: string;
  type: ComponentType;
  amountMonthly: number;
  amountAnnual: number;
}

export interface SalaryStructure {
  id: string;
  name: string;
  description: string;
  grossMonthly: number;
  ctcAnnual: number;
  items: SalaryStructureItem[];
  isActive: boolean;
}

export type PayrollRunStatus = 'Draft' | 'Preview' | 'Pending Approval' | 'Finalized' | 'Paid';

export interface PayrollLineItem {
  id: string;
  payrollRunId: string;
  employeeId: string;
  employeeName: string;
  departmentName: string;
  designationTitle: string;
  bankAccountNumber: string;
  panNumber: string;
  workingDaysInMonth: number;
  daysPresent: number;
  paidLeaves: number;
  unpaidLeaves: number; // LOP days
  payableDays: number;
  basicEarnings: number;
  hraEarnings: number;
  specialAllowanceEarnings: number;
  grossEarnings: number;
  // Deductions
  pfEmployee: number;
  esiEmployee: number;
  professionalTax: number;
  tdsWithholding: number;
  unpaidLeaveDeduction: number;
  otherDeductions: number;
  totalDeductions: number;
  netPayable: number;
  // Employer Cost
  pfEmployer: number;
  esiEmployer: number;
  totalEmployerCost: number;
  status: 'Calculated' | 'Finalized' | 'Paid';
}

export interface PayrollRun {
  id: string;
  month: number; // 1-12
  year: number;
  periodLabel: string; // e.g. "October 2026"
  startDate: string;
  endDate: string;
  totalEmployees: number;
  totalGrossPay: number;
  totalDeductions: number;
  totalNetPay: number;
  status: PayrollRunStatus;
  processedBy: string;
  approvedBy?: string;
  finalizedAt?: string;
  paymentReference?: string;
  paymentDate?: string;
  notes?: string;
}

// --------------------- MODULE 4: EXPENSES ---------------------
export interface ExpenseCategory {
  id: string;
  name: string;
  code: string;
  maxLimitPerClaim: number;
  requiresReceipt: boolean;
  description: string;
}

export type ExpenseClaimStatus = 
  | 'Draft' 
  | 'Pending Manager Approval' 
  | 'Approved' 
  | 'Rejected' 
  | 'Pending Reimbursement' 
  | 'Reimbursed';

export interface ExpenseClaim {
  id: string;
  claimNumber: string; // EXP-2026-001
  employeeId: string;
  categoryId: string;
  title: string;
  amount: number;
  currency: string;
  expenseDate: string; // YYYY-MM-DD
  businessPurpose: string;
  receiptFileName?: string;
  receiptUrl?: string;
  status: ExpenseClaimStatus;
  approverId: string;
  approvalComments?: string;
  reimbursementReference?: string;
  reimbursedAt?: string;
  submittedAt: string;
  decidedAt?: string;
  isDemo?: boolean;
}

// --------------------- MODULE 5: ASSET MANAGEMENT ---------------------
export type AssetCategoryType = 'Laptop' | 'Monitor' | 'Mobile Device' | 'Accessories' | 'Office Furniture' | 'Software License' | 'Email Account' | 'Subscription' | 'Cloud Access';

export interface AssetCategory {
  id: string;
  name: AssetCategoryType;
  code: string;
  depreciationRateAnnualPercent: number;
  description: string;
}

export type AssetStatus = 'Available' | 'Allocated' | 'Under Maintenance' | 'Retired' | 'Lost';
export type AllocationCondition = 'Brand New' | 'Good' | 'Fair' | 'Minor Scratches';

export interface Asset {
  id: string; // AST-001
  assetTag: string;
  name: string;
  category: AssetCategoryType;
  brand: string;
  model: string;
  serialNumber: string;
  purchaseDate: string;
  purchaseCost: number;
  warrantyExpiryDate: string;
  supplier: string;
  location: string;
  condition: AllocationCondition;
  status: AssetStatus;
  currentEmployeeId?: string;
  allocatedDate?: string;
  acknowledgedByEmployee: boolean;
  acknowledgedAt?: string;
  notes?: string;
  assetType?: 'Hardware' | 'Software & Digital';
  accountIdentifier?: string;
  licenseSeats?: number;
  renewalDate?: string;
  subscriptionCost?: number;
  billingFrequency?: 'Monthly' | 'Quarterly' | 'Annual' | 'One-time';
}

export interface AssetAssignmentHistory {
  id: string;
  assetId: string;
  employeeId: string;
  allocatedDate: string;
  returnedDate?: string;
  initialCondition: AllocationCondition;
  returnCondition?: AllocationCondition;
  notes?: string;
}

// --------------------- MODULE 6: SHIFTS & ATTENDANCE ---------------------
export interface ShiftDefinition {
  id: string;
  name: string;
  code: string;
  startTime: string; // HH:MM
  endTime: string; // HH:MM
  gracePeriodMinutes: number;
  breakDurationMinutes: number;
  totalWorkingHours: number;
  isOvernight: boolean;
  weeklyOffDays: number[]; // 0=Sun, 6=Sat
}

export type AttendanceStatus = 'Present' | 'Late' | 'Half Day' | 'Absent' | 'On Leave' | 'Holiday' | 'Weekly Off';

export interface AttendanceRecord {
  id: string;
  employeeId: string;
  date: string; // YYYY-MM-DD
  shiftId: string;
  checkInTime?: string; // HH:MM
  checkOutTime?: string; // HH:MM
  totalHoursWorked: number;
  regularHours: number;
  overtimeHours: number;
  status: AttendanceStatus;
  isLate: boolean;
  isEarlyDeparture: boolean;
  lateMinutes: number;
  source: 'Web Punch' | 'Manual HR Entry' | 'Biometric Import' | 'System Default';
  notes?: string;
}

export type CorrectionRequestStatus = 'Pending' | 'Approved' | 'Rejected';

export interface AttendanceCorrectionRequest {
  id: string;
  attendanceId?: string;
  employeeId: string;
  date: string;
  requestedCheckIn: string;
  requestedCheckOut: string;
  reason: string;
  status: CorrectionRequestStatus;
  approverId: string;
  approverComments?: string;
  submittedAt: string;
  decidedAt?: string;
  isDemo?: boolean;
}

// --------------------- AUDIT & NOTIFICATIONS ---------------------
export interface AuditLog {
  id: string;
  timestamp: string;
  actorUserId: string;
  actorName: string;
  actorRole: UserRole;
  action: 'CREATE' | 'UPDATE' | 'DELETE' | 'APPROVE' | 'REJECT' | 'FINALIZE' | 'REIMBURSE' | 'ALLOCATE' | 'LOGIN';
  module: 'EMPLOYEE' | 'LEAVE' | 'PAYROLL' | 'EXPENSE' | 'ASSET' | 'ATTENDANCE' | 'SYSTEM';
  entityId: string;
  entityName: string;
  description: string;
  metadata?: Record<string, any>;
}

export interface AppNotification {
  id: string;
  targetUserId: string;
  title: string;
  message: string;
  module: 'leave' | 'payroll' | 'expense' | 'asset' | 'attendance' | 'employee';
  isRead: boolean;
  createdAt: string;
  actionUrl?: string;
}

export interface CurrentUser {
  id: string;
  employeeId: string;
  name: string;
  email: string;
  role: UserRole;
  departmentId: string;
  designationTitle: string;
  avatarUrl: string;
}
