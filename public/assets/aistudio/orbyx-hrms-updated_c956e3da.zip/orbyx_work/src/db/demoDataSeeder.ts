import { db } from './storage';
import { LeaveApplication, ExpenseClaim, AttendanceCorrectionRequest } from '../types/hrms';

/**
 * Idempotent Demo Data Seeder
 * Populates realistic synthetic requests for active employees:
 * - 8 Software Engineers send requests to Krishnaraj (EMP-002)
 * - Krishnaraj (EMP-002) and Anamika (EMP-001) send requests to Dr. Selvakumar (EMP-000)
 * - Deactivated employees (EMP-005, EMP-006, EMP-007, EMP-008) are strictly excluded from new requests
 * - Tagged with isDemo: true
 */
export function seedRealisticDemoRequests(): {
  leavesCreated: number;
  expensesCreated: number;
  correctionsCreated: number;
} {
  const employees = db.getEmployees();
  const activeEmployees = employees.filter((e) => e.status !== 'Inactive' && e.status !== 'Separated');

  let leavesCreated = 0;
  let expensesCreated = 0;
  let correctionsCreated = 0;

  const existingLeaves = db.getLeaveApplications();
  const existingExpenses = db.getExpenseClaims();
  const existingCorrections = db.getCorrectionRequests();

  // -------------------------------------------------------------------------
  // 1. LEAVE APPLICATIONS
  // -------------------------------------------------------------------------
  // Anupriya (EMP-011) -> Pending to Krishnaraj (EMP-002)
  const demoLeaves: LeaveApplication[] = [
    {
      id: 'DEMO-LV-001',
      employeeId: 'EMP-011', // Anupriya
      leaveTypeId: 'LT-AL',
      startDate: '2026-10-28',
      endDate: '2026-10-30',
      isHalfDay: false,
      totalDays: 3,
      reason: '[DEMO] Annual family festival visit to Coimbatore',
      status: 'Pending Approval',
      approverId: 'EMP-002',
      appliedAt: '2026-10-22T09:15:00Z',
      isDemo: true
    },
    // Suguna (EMP-012) -> Pending to Krishnaraj (EMP-002)
    {
      id: 'DEMO-LV-002',
      employeeId: 'EMP-012', // Suguna
      leaveTypeId: 'LT-SL',
      startDate: '2026-10-27',
      endDate: '2026-10-27',
      isHalfDay: false,
      totalDays: 1,
      reason: '[DEMO] Dental surgery appointment and rest',
      status: 'Pending Approval',
      approverId: 'EMP-002',
      appliedAt: '2026-10-23T08:00:00Z',
      isDemo: true
    },
    // Praveen (EMP-013) -> Pending to Krishnaraj (EMP-002)
    {
      id: 'DEMO-LV-003',
      employeeId: 'EMP-013', // Praveen
      leaveTypeId: 'LT-CL',
      startDate: '2026-11-04',
      endDate: '2026-11-04',
      isHalfDay: true,
      halfDayPeriod: 'First Half',
      totalDays: 0.5,
      reason: '[DEMO] Driving license renewal at RTO',
      status: 'Pending Approval',
      approverId: 'EMP-002',
      appliedAt: '2026-10-21T11:30:00Z',
      isDemo: true
    },
    // Karthiga (EMP-014) -> Approved by Krishnaraj
    {
      id: 'DEMO-LV-004',
      employeeId: 'EMP-014', // Karthiga
      leaveTypeId: 'LT-AL',
      startDate: '2026-10-14',
      endDate: '2026-10-16',
      isHalfDay: false,
      totalDays: 3,
      reason: '[DEMO] Sister engagement ceremony in Madurai',
      status: 'Approved',
      approverId: 'EMP-002',
      approvalComments: 'Approved. Sprint deliverables reassigned.',
      appliedAt: '2026-10-05T10:00:00Z',
      decidedAt: '2026-10-06T15:00:00Z',
      isDemo: true
    },
    // Priyadharshini (EMP-015) -> Pending to Krishnaraj
    {
      id: 'DEMO-LV-005',
      employeeId: 'EMP-015', // Priyadharshini
      leaveTypeId: 'LT-AL',
      startDate: '2026-11-10',
      endDate: '2026-11-12',
      isHalfDay: false,
      totalDays: 3,
      reason: '[DEMO] Attending technical symposium on Cloud Architecture',
      status: 'Pending Approval',
      approverId: 'EMP-002',
      appliedAt: '2026-10-22T16:00:00Z',
      isDemo: true
    },
    // Niranjan (EMP-016) -> Rejected by Krishnaraj
    {
      id: 'DEMO-LV-006',
      employeeId: 'EMP-016', // Niranjan
      leaveTypeId: 'LT-CL',
      startDate: '2026-10-29',
      endDate: '2026-10-30',
      isHalfDay: false,
      totalDays: 2,
      reason: '[DEMO] Long weekend road trip',
      status: 'Rejected',
      approverId: 'EMP-002',
      approvalComments: 'Client deployment window on Oct 29. Please reschedule.',
      appliedAt: '2026-10-20T14:00:00Z',
      decidedAt: '2026-10-21T09:30:00Z',
      isDemo: true
    },
    // Archana (EMP-003) -> Pending to Krishnaraj
    {
      id: 'DEMO-LV-007',
      employeeId: 'EMP-003', // Archana
      leaveTypeId: 'LT-AL',
      startDate: '2026-11-05',
      endDate: '2026-11-06',
      isHalfDay: false,
      totalDays: 2,
      reason: '[DEMO] Personal travel and wellness break',
      status: 'Pending Approval',
      approverId: 'EMP-002',
      appliedAt: '2026-10-22T10:00:00Z',
      isDemo: true
    },
    // Krishnaraj (EMP-002) -> Pending to Dr. Selvakumar (EMP-000)
    {
      id: 'DEMO-LV-008',
      employeeId: 'EMP-002', // Krishnaraj
      leaveTypeId: 'LT-AL',
      startDate: '2026-11-16',
      endDate: '2026-11-18',
      isHalfDay: false,
      totalDays: 3,
      reason: '[DEMO] Enterprise Tech Leadership Summit attendance in Mumbai',
      status: 'Pending Approval',
      approverId: 'EMP-000', // Dr. Selvakumar
      appliedAt: '2026-10-23T07:30:00Z',
      isDemo: true
    },
    // Anamika (EMP-001) -> Pending to Dr. Selvakumar (EMP-000)
    {
      id: 'DEMO-LV-009',
      employeeId: 'EMP-001', // Anamika
      leaveTypeId: 'LT-AL',
      startDate: '2026-11-23',
      endDate: '2026-11-25',
      isHalfDay: false,
      totalDays: 3,
      reason: '[DEMO] National HR Conclave 2026 in New Delhi',
      status: 'Pending Approval',
      approverId: 'EMP-000', // Dr. Selvakumar
      appliedAt: '2026-10-22T12:00:00Z',
      isDemo: true
    }
  ];

  for (const item of demoLeaves) {
    if (!existingLeaves.some((l) => l.id === item.id)) {
      db.saveLeaveApplication(item);
      leavesCreated++;
    }
  }

  // -------------------------------------------------------------------------
  // 2. EXPENSE CLAIMS
  // -------------------------------------------------------------------------
  const demoExpenses: ExpenseClaim[] = [
    // Anupriya -> Pending to Krishnaraj
    {
      id: 'DEMO-EXP-001',
      claimNumber: 'EXP-2026-101',
      employeeId: 'EMP-011',
      categoryId: 'CAT-CONV',
      title: '[DEMO] Client site travel cab reimbursement (Whitefield)',
      amount: 1450,
      currency: 'INR',
      expenseDate: '2026-10-20',
      businessPurpose: 'On-site integration testing at enterprise customer facility',
      receiptFileName: 'uber_receipt_oct20_1450.pdf',
      status: 'Pending Manager Approval',
      approverId: 'EMP-002',
      submittedAt: '2026-10-21T09:00:00Z',
      isDemo: true
    },
    // Praveen -> Pending to Krishnaraj
    {
      id: 'DEMO-EXP-002',
      claimNumber: 'EXP-2026-102',
      employeeId: 'EMP-013',
      categoryId: 'CAT-SUPP',
      title: '[DEMO] Ergonomic keyboard & mouse for engineering station',
      amount: 3200,
      currency: 'INR',
      expenseDate: '2026-10-18',
      businessPurpose: 'Replacement input accessories under workplace ergonomics policy',
      receiptFileName: 'amazon_tax_invoice_mouse.pdf',
      status: 'Pending Manager Approval',
      approverId: 'EMP-002',
      submittedAt: '2026-10-19T14:30:00Z',
      isDemo: true
    },
    // Mahalakshmi -> Approved, Pending Reimbursement
    {
      id: 'DEMO-EXP-003',
      claimNumber: 'EXP-2026-103',
      employeeId: 'EMP-004',
      categoryId: 'CAT-MEAL',
      title: '[DEMO] Team sprint lunch during release deployment weekend',
      amount: 2800,
      currency: 'INR',
      expenseDate: '2026-10-12',
      businessPurpose: 'Working lunch for engineering release squad',
      receiptFileName: 'swiggy_invoice_lunch.pdf',
      status: 'Pending Reimbursement',
      approverId: 'EMP-002',
      approvalComments: 'Approved by Delivery Manager. Forwarded to finance for payout.',
      submittedAt: '2026-10-13T11:00:00Z',
      decidedAt: '2026-10-14T10:00:00Z',
      isDemo: true
    },
    // Suguna -> Reimbursed
    {
      id: 'DEMO-EXP-004',
      claimNumber: 'EXP-2026-104',
      employeeId: 'EMP-012',
      categoryId: 'CAT-CONV',
      title: '[DEMO] Airport cab conveyance for client workshop',
      amount: 1850,
      currency: 'INR',
      expenseDate: '2026-09-28',
      businessPurpose: 'Airport pickup and drop for Chennai tech briefing',
      receiptFileName: 'cab_toll_receipt.pdf',
      status: 'Reimbursed',
      approverId: 'EMP-002',
      reimbursementReference: 'NEFT-AXIS-98214',
      reimbursedAt: '2026-10-05T16:00:00Z',
      submittedAt: '2026-09-29T10:00:00Z',
      decidedAt: '2026-09-30T11:00:00Z',
      isDemo: true
    },
    // Krishnaraj (EMP-002) -> Pending to Dr. Selvakumar (EMP-000)
    {
      id: 'DEMO-EXP-005',
      claimNumber: 'EXP-2026-105',
      employeeId: 'EMP-002', // Krishnaraj
      categoryId: 'CAT-TRV',
      title: '[DEMO] Flight tickets for Hyderabad client delivery review',
      amount: 11200,
      currency: 'INR',
      expenseDate: '2026-10-15',
      businessPurpose: 'Q3 Enterprise Architecture steering committee meeting',
      receiptFileName: 'indigo_flight_hyd_blr.pdf',
      status: 'Pending Manager Approval',
      approverId: 'EMP-000', // Dr. Selvakumar
      submittedAt: '2026-10-16T17:00:00Z',
      isDemo: true
    },
    // Anamika (EMP-001) -> Pending to Dr. Selvakumar (EMP-000)
    {
      id: 'DEMO-EXP-006',
      claimNumber: 'EXP-2026-106',
      employeeId: 'EMP-001', // Anamika
      categoryId: 'CAT-MISC',
      title: '[DEMO] Annual campus hiring booth branding & merchandise',
      amount: 8500,
      currency: 'INR',
      expenseDate: '2026-10-19',
      businessPurpose: 'Collaterals and booth banners for RVCE Engineering campus drive',
      receiptFileName: 'printo_branding_materials.pdf',
      status: 'Pending Manager Approval',
      approverId: 'EMP-000', // Dr. Selvakumar
      submittedAt: '2026-10-20T11:30:00Z',
      isDemo: true
    }
  ];

  for (const item of demoExpenses) {
    if (!existingExpenses.some((e) => e.id === item.id)) {
      db.saveExpenseClaim(item);
      expensesCreated++;
    }
  }

  // -------------------------------------------------------------------------
  // 3. ATTENDANCE CORRECTIONS
  // -------------------------------------------------------------------------
  const demoCorrections: AttendanceCorrectionRequest[] = [
    // Karthiga (EMP-014) -> Pending to Krishnaraj (EMP-002)
    {
      id: 'DEMO-CORR-001',
      employeeId: 'EMP-014',
      date: '2026-10-21',
      requestedCheckIn: '09:25',
      requestedCheckOut: '18:35',
      reason: '[DEMO] Biometric scanner network outage at Bengaluru lobby entrance',
      status: 'Pending',
      approverId: 'EMP-002',
      submittedAt: '2026-10-21T19:00:00Z',
      isDemo: true
    },
    // Priyadharshini (EMP-015) -> Pending to Krishnaraj (EMP-002)
    {
      id: 'DEMO-CORR-002',
      employeeId: 'EMP-015',
      date: '2026-10-22',
      requestedCheckIn: '09:30',
      requestedCheckOut: '19:15',
      reason: '[DEMO] Missed web check-out due to client escalation call',
      status: 'Pending',
      approverId: 'EMP-002',
      submittedAt: '2026-10-22T20:10:00Z',
      isDemo: true
    },
    // Krishnaraj (EMP-002) -> Pending to Dr. Selvakumar (EMP-000)
    {
      id: 'DEMO-CORR-003',
      employeeId: 'EMP-002',
      date: '2026-10-20',
      requestedCheckIn: '09:15',
      requestedCheckOut: '19:45',
      reason: '[DEMO] Direct transit to executive customer briefing without office badge swipe',
      status: 'Pending',
      approverId: 'EMP-000', // Dr. Selvakumar
      submittedAt: '2026-10-21T08:30:00Z',
      isDemo: true
    }
  ];

  for (const item of demoCorrections) {
    if (!existingCorrections.some((c) => c.id === item.id)) {
      db.saveCorrectionRequest(item);
      correctionsCreated++;
    }
  }

  return { leavesCreated, expensesCreated, correctionsCreated };
}
