import {
  CompanyProfile,
  Branch,
  Department,
  Designation,
  Employee,
  LeaveType,
  LeaveApplication,
  Holiday,
  SalaryComponent,
  SalaryStructure,
  PayrollRun,
  PayrollLineItem,
  ExpenseCategory,
  ExpenseClaim,
  Asset,
  ShiftDefinition,
  AttendanceRecord,
  AttendanceCorrectionRequest,
  AuditLog,
  AppNotification
} from '../types/hrms';
import {
  initialCompanyProfile,
  initialBranches,
  initialDepartments,
  initialDesignations,
  initialShifts,
  initialLeaveTypes,
  initialHolidays,
  initialSalaryComponents,
  initialSalaryStructures,
  initialEmployees,
  initialLeaveApplications,
  initialExpenseCategories,
  initialExpenseClaims,
  initialAssets,
  initialAttendanceRecords,
  initialCorrectionRequests,
  initialPayrollRuns,
  initialPayrollLineItems,
  initialAuditLogs,
  initialNotifications
} from './initialData';
import { seedRealisticDemoRequests } from './demoDataSeeder';

const DB_PREFIX = 'orbyx_hrms_v3_';

type StorageListener = () => void;
const listeners = new Set<StorageListener>();

export function subscribeToDB(listener: StorageListener): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

function notifySubscribers() {
  listeners.forEach((listener) => {
    try {
      listener();
    } catch (e) {
      console.error('Error in DB subscriber:', e);
    }
  });
}

function getItem<T>(key: string, defaultValue: T): T {
  try {
    const raw = localStorage.getItem(DB_PREFIX + key);
    if (!raw) return defaultValue;
    return JSON.parse(raw) as T;
  } catch (e) {
    console.error(`Failed to read ${key} from storage:`, e);
    return defaultValue;
  }
}

function setItem<T>(key: string, value: T): void {
  try {
    localStorage.setItem(DB_PREFIX + key, JSON.stringify(value));
    notifySubscribers();
  } catch (e) {
    console.error(`Failed to write ${key} to storage:`, e);
  }
}

export function initDatabase(): void {
  if (!localStorage.getItem(DB_PREFIX + 'initialized')) {
    resetToSeedData();
  } else {
    // Idempotent demo request check
    seedRealisticDemoRequests();
  }
}

export function resetToSeedData(): void {
  localStorage.setItem(DB_PREFIX + 'companyProfile', JSON.stringify(initialCompanyProfile));
  localStorage.setItem(DB_PREFIX + 'branches', JSON.stringify(initialBranches));
  localStorage.setItem(DB_PREFIX + 'departments', JSON.stringify(initialDepartments));
  localStorage.setItem(DB_PREFIX + 'designations', JSON.stringify(initialDesignations));
  localStorage.setItem(DB_PREFIX + 'shifts', JSON.stringify(initialShifts));
  localStorage.setItem(DB_PREFIX + 'leaveTypes', JSON.stringify(initialLeaveTypes));
  localStorage.setItem(DB_PREFIX + 'holidays', JSON.stringify(initialHolidays));
  localStorage.setItem(DB_PREFIX + 'salaryComponents', JSON.stringify(initialSalaryComponents));
  localStorage.setItem(DB_PREFIX + 'salaryStructures', JSON.stringify(initialSalaryStructures));
  localStorage.setItem(DB_PREFIX + 'employees', JSON.stringify(initialEmployees));
  localStorage.setItem(DB_PREFIX + 'leaveApplications', JSON.stringify(initialLeaveApplications));
  localStorage.setItem(DB_PREFIX + 'expenseCategories', JSON.stringify(initialExpenseCategories));
  localStorage.setItem(DB_PREFIX + 'expenseClaims', JSON.stringify(initialExpenseClaims));
  localStorage.setItem(DB_PREFIX + 'assets', JSON.stringify(initialAssets));
  localStorage.setItem(DB_PREFIX + 'attendanceRecords', JSON.stringify(initialAttendanceRecords));
  localStorage.setItem(DB_PREFIX + 'correctionRequests', JSON.stringify(initialCorrectionRequests));
  localStorage.setItem(DB_PREFIX + 'payrollRuns', JSON.stringify(initialPayrollRuns));
  localStorage.setItem(DB_PREFIX + 'payrollLineItems', JSON.stringify(initialPayrollLineItems));
  localStorage.setItem(DB_PREFIX + 'auditLogs', JSON.stringify(initialAuditLogs));
  localStorage.setItem(DB_PREFIX + 'notifications', JSON.stringify(initialNotifications));
  localStorage.setItem(DB_PREFIX + 'initialized', 'true');
  seedRealisticDemoRequests();
  notifySubscribers();
}

// ---------------- TYPED REPOSITORIES ----------------

export const db = {
  // Company Profile
  getCompanyProfile(): CompanyProfile {
    return getItem<CompanyProfile>('companyProfile', initialCompanyProfile);
  },
  updateCompanyProfile(profile: Partial<CompanyProfile>): CompanyProfile {
    const current = this.getCompanyProfile();
    const updated = { ...current, ...profile };
    setItem('companyProfile', updated);
    return updated;
  },

  // Branches
  getBranches(): Branch[] {
    return getItem<Branch[]>('branches', initialBranches);
  },
  saveBranch(branch: Branch): void {
    const list = this.getBranches();
    const idx = list.findIndex((b) => b.id === branch.id);
    if (idx >= 0) list[idx] = branch;
    else list.push(branch);
    setItem('branches', list);
  },

  // Departments
  getDepartments(): Department[] {
    return getItem<Department[]>('departments', initialDepartments);
  },
  saveDepartment(dept: Department): void {
    const list = this.getDepartments();
    const idx = list.findIndex((d) => d.id === dept.id);
    if (idx >= 0) list[idx] = dept;
    else list.push(dept);
    setItem('departments', list);
  },

  // Designations
  getDesignations(): Designation[] {
    return getItem<Designation[]>('designations', initialDesignations);
  },
  saveDesignation(desig: Designation): void {
    const list = this.getDesignations();
    const idx = list.findIndex((d) => d.id === desig.id);
    if (idx >= 0) list[idx] = desig;
    else list.push(desig);
    setItem('designations', list);
  },

  // Employees
  getEmployees(): Employee[] {
    return getItem<Employee[]>('employees', initialEmployees);
  },
  getEmployeeById(id: string): Employee | undefined {
    return this.getEmployees().find((e) => e.id === id);
  },
  getEmployeeByUserId(userId: string): Employee | undefined {
    return this.getEmployees().find((e) => e.userId === userId);
  },
  saveEmployee(emp: Employee): void {
    const list = this.getEmployees();
    const idx = list.findIndex((e) => e.id === emp.id);
    if (idx >= 0) list[idx] = emp;
    else list.push(emp);
    setItem('employees', list);
  },

  // Shifts
  getShifts(): ShiftDefinition[] {
    return getItem<ShiftDefinition[]>('shifts', initialShifts);
  },
  saveShift(shift: ShiftDefinition): void {
    const list = this.getShifts();
    const idx = list.findIndex((s) => s.id === shift.id);
    if (idx >= 0) list[idx] = shift;
    else list.push(shift);
    setItem('shifts', list);
  },

  // Leave Types & Policies
  getLeaveTypes(): LeaveType[] {
    return getItem<LeaveType[]>('leaveTypes', initialLeaveTypes);
  },
  saveLeaveType(lt: LeaveType): void {
    const list = this.getLeaveTypes();
    const idx = list.findIndex((l) => l.id === lt.id);
    if (idx >= 0) list[idx] = lt;
    else list.push(lt);
    setItem('leaveTypes', list);
  },

  // Holidays
  getHolidays(): Holiday[] {
    return getItem<Holiday[]>('holidays', initialHolidays);
  },
  saveHoliday(h: Holiday): void {
    const list = this.getHolidays();
    const idx = list.findIndex((item) => item.id === h.id);
    if (idx >= 0) list[idx] = h;
    else list.push(h);
    setItem('holidays', list);
  },
  deleteHoliday(id: string): void {
    const list = this.getHolidays().filter((h) => h.id !== id);
    setItem('holidays', list);
  },

  // Leave Applications
  getLeaveApplications(): LeaveApplication[] {
    return getItem<LeaveApplication[]>('leaveApplications', initialLeaveApplications);
  },
  saveLeaveApplication(app: LeaveApplication): void {
    const list = this.getLeaveApplications();
    const idx = list.findIndex((a) => a.id === app.id);
    if (idx >= 0) list[idx] = app;
    else list.unshift(app);
    setItem('leaveApplications', list);
  },

  // Salary Components & Structures
  getSalaryComponents(): SalaryComponent[] {
    return getItem<SalaryComponent[]>('salaryComponents', initialSalaryComponents);
  },
  getSalaryStructures(): SalaryStructure[] {
    return getItem<SalaryStructure[]>('salaryStructures', initialSalaryStructures);
  },
  saveSalaryStructure(structure: SalaryStructure): void {
    const list = this.getSalaryStructures();
    const idx = list.findIndex((s) => s.id === structure.id);
    if (idx >= 0) list[idx] = structure;
    else list.push(structure);
    setItem('salaryStructures', list);
  },

  // Payroll Runs & Line Items
  getPayrollRuns(): PayrollRun[] {
    return getItem<PayrollRun[]>('payrollRuns', initialPayrollRuns);
  },
  savePayrollRun(run: PayrollRun): void {
    const list = this.getPayrollRuns();
    const idx = list.findIndex((r) => r.id === run.id);
    if (idx >= 0) list[idx] = run;
    else list.unshift(run);
    setItem('payrollRuns', list);
  },
  getPayrollLineItems(runId?: string): PayrollLineItem[] {
    const items = getItem<PayrollLineItem[]>('payrollLineItems', initialPayrollLineItems);
    if (runId) return items.filter((item) => item.payrollRunId === runId);
    return items;
  },
  savePayrollLineItems(newItems: PayrollLineItem[]): void {
    const current = getItem<PayrollLineItem[]>('payrollLineItems', initialPayrollLineItems);
    const map = new Map(current.map((item) => [item.id, item]));
    newItems.forEach((item) => map.set(item.id, item));
    setItem('payrollLineItems', Array.from(map.values()));
  },

  // Expense Categories & Claims
  getExpenseCategories(): ExpenseCategory[] {
    return getItem<ExpenseCategory[]>('expenseCategories', initialExpenseCategories);
  },
  saveExpenseCategory(cat: ExpenseCategory): void {
    const list = this.getExpenseCategories();
    const idx = list.findIndex((c) => c.id === cat.id);
    if (idx >= 0) list[idx] = cat;
    else list.push(cat);
    setItem('expenseCategories', list);
  },
  getExpenseClaims(): ExpenseClaim[] {
    return getItem<ExpenseClaim[]>('expenseClaims', initialExpenseClaims);
  },
  saveExpenseClaim(claim: ExpenseClaim): void {
    const list = this.getExpenseClaims();
    const idx = list.findIndex((c) => c.id === claim.id);
    if (idx >= 0) list[idx] = claim;
    else list.unshift(claim);
    setItem('expenseClaims', list);
  },

  // Assets
  getAssets(): Asset[] {
    return getItem<Asset[]>('assets', initialAssets);
  },
  getAssetById(id: string): Asset | undefined {
    return this.getAssets().find((a) => a.id === id);
  },
  saveAsset(asset: Asset): void {
    const list = this.getAssets();
    const idx = list.findIndex((a) => a.id === asset.id);
    if (idx >= 0) list[idx] = asset;
    else list.push(asset);
    setItem('assets', list);
  },

  // Attendance & Corrections
  getAttendanceRecords(): AttendanceRecord[] {
    return getItem<AttendanceRecord[]>('attendanceRecords', initialAttendanceRecords);
  },
  saveAttendanceRecord(rec: AttendanceRecord): void {
    const list = this.getAttendanceRecords();
    const idx = list.findIndex((r) => r.id === rec.id);
    if (idx >= 0) list[idx] = rec;
    else list.unshift(rec);
    setItem('attendanceRecords', list);
  },
  getCorrectionRequests(): AttendanceCorrectionRequest[] {
    return getItem<AttendanceCorrectionRequest[]>('correctionRequests', initialCorrectionRequests);
  },
  saveCorrectionRequest(req: AttendanceCorrectionRequest): void {
    const list = this.getCorrectionRequests();
    const idx = list.findIndex((r) => r.id === req.id);
    if (idx >= 0) list[idx] = req;
    else list.unshift(req);
    setItem('correctionRequests', list);
  },

  // Audit Logs
  getAuditLogs(): AuditLog[] {
    return getItem<AuditLog[]>('auditLogs', initialAuditLogs);
  },
  logAudit(log: Omit<AuditLog, 'id' | 'timestamp'>): void {
    const list = this.getAuditLogs();
    const entry: AuditLog = {
      ...log,
      id: `AUD-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString()
    };
    list.unshift(entry);
    // Keep last 300 logs
    setItem('auditLogs', list.slice(0, 300));
  },

  // Notifications
  getNotifications(userId?: string): AppNotification[] {
    const list = getItem<AppNotification[]>('notifications', initialNotifications);
    if (userId) {
      return list.filter((n) => n.targetUserId === userId || n.targetUserId === 'all');
    }
    return list;
  },
  addNotification(notif: Omit<AppNotification, 'id' | 'createdAt' | 'isRead'>): void {
    const list = getItem<AppNotification[]>('notifications', initialNotifications);
    const entry: AppNotification = {
      ...notif,
      id: `NOTIF-${Date.now()}`,
      isRead: false,
      createdAt: new Date().toISOString()
    };
    list.unshift(entry);
    setItem('notifications', list.slice(0, 50));
  },
  markNotificationRead(id: string): void {
    const list = getItem<AppNotification[]>('notifications', initialNotifications);
    const notif = list.find((n) => n.id === id);
    if (notif) {
      notif.isRead = true;
      setItem('notifications', list);
    }
  },
  markAllNotificationsRead(userId: string): void {
    const list = getItem<AppNotification[]>('notifications', initialNotifications);
    list.forEach((n) => {
      if (n.targetUserId === userId || n.targetUserId === 'all') {
        n.isRead = true;
      }
    });
    setItem('notifications', list);
  }
};
