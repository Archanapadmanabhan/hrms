import React, { useState } from 'react';
import { db } from '../../db/storage';
import { Asset, AllocationCondition } from '../../types/hrms';
import { useAuth } from '../../services/authContext';
import { hrmsService } from '../../services/hrmsService';
import { DataTable, Column } from '../common/DataTable';
import { ExportButton } from '../common/ExportButton';
import { StatCard } from '../common/StatCard';
import { RegisterAssetModal } from './RegisterAssetModal';
import { AllocateAssetModal } from './AllocateAssetModal';
import {
  Laptop,
  CheckCircle2,
  Package,
  Plus,
  UserCheck,
  RotateCcw,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';

export const AssetManagement: React.FC = () => {
  const isHR = canManageOrganization();
  const isSeniorManager = currentUser.role === 'senior_manager';
  const isReportingManager = currentUser.role === 'reporting_manager';
  const isEmployee = currentUser.role === 'employee';

  const [activeTab, setActiveTab] = useState<'all' | 'myAssets' | 'teamAssets'>((isHR || isSeniorManager) ? 'all' : (isReportingManager ? 'teamAssets' : 'myAssets'));
  const [isRegisterModalOpen, setIsRegisterModalOpen] = useState(false);
  const [allocatingAsset, setAllocatingAsset] = useState<Asset | null>(null);

  // Return modal
  const [returningAsset, setReturningAsset] = useState<Asset | null>(null);
  const [returnCondition, setReturnCondition] = useState<AllocationCondition>('Good');
  const [returnNotes, setReturnNotes] = useState('');

  const assets = db.getAssets();
  const employees = db.getEmployees();

  // Team direct report IDs for manager
  const teamMemberIds = employees
    .filter((e) => e.reportingManagerId === currentUser.employeeId)
    .map((e) => e.id);

  const myAssets = assets.filter((a) => a.currentEmployeeId === currentUser.employeeId);
  const teamAssets = assets.filter((a) => a.currentEmployeeId && teamMemberIds.includes(a.currentEmployeeId));

  const allocatedCount = assets.filter((a) => a.status === 'Allocated').length;
  const availableCount = assets.filter((a) => a.status === 'Available').length;
  const totalValuation = assets.reduce((acc, a) => acc + a.purchaseCost, 0);

  const handleReturnConfirm = () => {
    if (!returningAsset) return;
    hrmsService.returnAsset(
      returningAsset.id,
      returnCondition,
      returnNotes,
      currentUser.id,
      currentUser.name
    );
    setReturningAsset(null);
    setReturnNotes('');
  };

  const handleAcknowledge = (assetId: string) => {
    hrmsService.acknowledgeAssetReceipt(assetId, currentUser.id, currentUser.name);
  };

  const columns: Column<Asset>[] = [
    {
      header: 'Asset Details',
      accessorKey: 'name',
      sortable: true,
      cell: (asset) => (
        <div>
          <span className="font-bold text-slate-900">{asset.name}</span>
          <div className="text-[11px] text-slate-500 flex items-center gap-1.5 mt-0.5">
            <span className="font-mono text-indigo-700 font-semibold">{asset.assetTag}</span>
            <span>·</span>
            <span>{asset.category}</span>
          </div>
        </div>
      )
    },
    {
      header: 'Brand & Serial',
      accessorKey: 'serialNumber',
      sortable: true,
      cell: (asset) => (
        <div>
          <span className="font-medium text-slate-800">{asset.brand} - {asset.model}</span>
          <span className="text-[11px] text-slate-500 block font-mono">SN: {asset.serialNumber}</span>
        </div>
      )
    },
    {
      header: 'Assigned To',
      accessorKey: 'currentEmployeeId',
      sortable: true,
      cell: (asset) => {
        if (!asset.currentEmployeeId) {
          return <span className="text-slate-400 italic">Unassigned (In Stock)</span>;
        }
        const emp = employees.find((e) => e.id === asset.currentEmployeeId);
        return (
          <div>
            <span className="font-semibold text-slate-900">
              {emp ? `${emp.firstName} ${emp.lastName}` : asset.currentEmployeeId}
            </span>
            <div className="flex items-center gap-1 mt-0.5">
              {asset.acknowledgedByEmployee ? (
                <span className="text-[10px] text-emerald-700 flex items-center gap-0.5 font-medium">
                  <CheckCircle2 className="h-3 w-3" /> Acknowledged
                </span>
              ) : (
                <span className="text-[10px] text-amber-700 font-medium">Pending Ack</span>
              )}
            </div>
          </div>
        );
      }
    },
    {
      header: 'Purchase & Warranty',
      accessorKey: 'purchaseCost',
      sortable: true,
      cell: (asset) => (
        <div>
          <span className="font-mono font-bold text-slate-900">₹{asset.purchaseCost.toLocaleString()}</span>
          <span className="text-[11px] text-slate-400 block">Warranty to {asset.warrantyExpiryDate}</span>
        </div>
      )
    },
    {
      header: 'Status',
      accessorKey: 'status',
      sortable: true,
      cell: (asset) => (
        <span
          className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
            asset.status === 'Available'
              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
              : asset.status === 'Allocated'
              ? 'bg-blue-50 text-blue-700 border border-blue-200'
              : 'bg-amber-50 text-amber-700 border border-amber-200'
          }`}
        >
          {asset.status}
        </span>
      )
    },
    {
      header: 'Actions',
      cell: (asset) => {
        const isAssignedToMe = asset.currentEmployeeId === currentUser.employeeId;

        return (
          <div className="flex items-center gap-1.5">
            {isHR && asset.status === 'Available' && (
              <button
                onClick={() => setAllocatingAsset(asset)}
                className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg text-xs font-semibold transition-colors"
              >
                Allocate
              </button>
            )}

            {isHR && asset.status === 'Allocated' && (
              <button
                onClick={() => setReturningAsset(asset)}
                className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-medium transition-colors"
              >
                Return
              </button>
            )}

            {isAssignedToMe && !asset.acknowledgedByEmployee && (
              <button
                onClick={() => handleAcknowledge(asset.id)}
                className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold transition-colors"
              >
                Acknowledge
              </button>
            )}
          </div>
        );
      }
    }
  ];

  // Current displayed assets based on role and tab
  const displayAssets = isEmployee
    ? myAssets
    : (activeTab === 'myAssets' ? myAssets : (activeTab === 'teamAssets' ? teamAssets : assets));

  const exportData = displayAssets.map((a) => ({
    AssetTag: a.assetTag,
    Name: a.name,
    Category: a.category,
    Brand: a.brand,
    Model: a.model,
    SerialNumber: isEmployee ? '••••••••' : a.serialNumber,
    PurchaseCost: isEmployee ? 0 : a.purchaseCost,
    PurchaseDate: a.purchaseDate,
    WarrantyExpiry: a.warrantyExpiryDate,
    Status: a.status,
    CurrentEmployeeID: a.currentEmployeeId || 'None',
    Condition: a.condition
  }));

  return (
    <div className="space-y-6">
      {/* Stat Cards */}
      {(isHR || isSeniorManager) ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Total Registered Assets"
            value={assets.length}
            subtitle="Enterprise IT hardware catalog"
            icon={Laptop}
            badge="Tracked"
            badgeColor="slate"
          />
          <StatCard
            title="Allocated Workstations"
            value={allocatedCount}
            subtitle={`${myAssets.length} allocated to you`}
            icon={UserCheck}
            badge="In Deployment"
            badgeColor="blue"
          />
          <StatCard
            title="In Stock / Available"
            value={availableCount}
            subtitle="Ready for new onboarding"
            icon={Package}
            badge={availableCount > 0 ? 'Stock Ready' : 'Low Inventory'}
            badgeColor={availableCount > 0 ? 'emerald' : 'amber'}
          />
          <StatCard
            title="Hardware Valuation"
            value={`₹${totalValuation.toLocaleString()}`}
            subtitle="Procurement cost total"
            icon={ShieldCheck}
            badge="Audited"
            badgeColor="indigo"
          />
        </div>
      ) : isReportingManager ? (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <StatCard
            title="Team Assets"
            value={teamAssets.length}
            subtitle="Hardware deployed to your direct reports"
            icon={Laptop}
            badge="Team Scope"
            badgeColor="indigo"
          />
          <StatCard
            title="My Assigned Hardware"
            value={myAssets.length}
            subtitle="Equipment allocated for your use"
            icon={UserCheck}
            badge="Active"
            badgeColor="blue"
          />
          <StatCard
            title="Acknowledged"
            value={teamAssets.filter((a) => a.acknowledgedByEmployee).length}
            subtitle="Receipt confirmed by team"
            icon={CheckCircle2}
            badge="Verified"
            badgeColor="emerald"
          />
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <StatCard
            title="My Assigned Hardware"
            value={myAssets.length}
            subtitle="Equipment allocated to you"
            icon={Laptop}
            badge="Self-Service"
            badgeColor="indigo"
          />
          <StatCard
            title="Acknowledgement Status"
            value={myAssets.every((a) => a.acknowledgedByEmployee) ? 'All Confirmed' : 'Action Pending'}
            subtitle="Custody receipt status"
            icon={ShieldCheck}
            badge="Compliance"
            badgeColor={myAssets.every((a) => a.acknowledgedByEmployee) ? 'emerald' : 'amber'}
          />
        </div>
      )}

      {/* Tabs and Actions Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white p-3.5 rounded-xl border border-slate-200">
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
          {(isHR || isSeniorManager) && (
            <button
              onClick={() => setActiveTab('all')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                activeTab === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Organization Assets ({assets.length})
            </button>
          )}
          {isReportingManager && (
            <button
              onClick={() => setActiveTab('teamAssets')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                activeTab === 'teamAssets' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Team Assets ({teamAssets.length})
            </button>
          )}
          <button
            onClick={() => setActiveTab('myAssets')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'myAssets' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            My Assigned Assets ({myAssets.length})
          </button>
        </div>

        <div className="flex items-center gap-2">
          <ExportButton data={exportData} fileName={isEmployee ? `Orbyx_My_Assets_${currentUser.employeeId}` : 'Orbyx_Asset_Inventory'} />
          {isHR && (
            <button
              onClick={() => setIsRegisterModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg shadow-2xs transition-colors"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>Register New Asset</span>
            </button>
          )}
        </div>
      </div>

      {/* Table Content */}
      <DataTable
        data={displayAssets}
        columns={columns}
        searchPlaceholder="Search assets by tag, serial number, brand, or model..."
        searchFilterKey={(a) => `${a.name} ${a.assetTag} ${a.serialNumber} ${a.brand}`}
      />

      {/* Register Modal */}
      <RegisterAssetModal
        isOpen={isRegisterModalOpen}
        onClose={() => setIsRegisterModalOpen(false)}
      />

      {/* Allocate Modal */}
      <AllocateAssetModal
        asset={allocatingAsset}
        isOpen={!!allocatingAsset}
        onClose={() => setAllocatingAsset(null)}
      />

      {/* Return Asset Modal */}
      {returningAsset && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-xl border border-slate-200 space-y-4 text-xs">
            <h4 className="text-base font-bold text-slate-900">Process Asset Return</h4>
            <p className="text-slate-600">
              Returning <span className="font-semibold text-slate-800">{returningAsset.name}</span> ({returningAsset.assetTag}).
            </p>
            <div>
              <label className="block text-slate-600 font-medium mb-1">Inspected Return Condition *</label>
              <select
                value={returnCondition}
                onChange={(e) => setReturnCondition(e.target.value as any)}
                className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg"
              >
                <option value="Good">Good (Working fine, normal wear)</option>
                <option value="Fair">Fair (Minor cosmetic blemishes)</option>
                <option value="Minor Scratches">Minor Scratches</option>
              </select>
            </div>
            <div>
              <label className="block text-slate-600 font-medium mb-1">Return Notes / Reason</label>
              <textarea
                value={returnNotes}
                onChange={(e) => setReturnNotes(e.target.value)}
                placeholder="e.g. Employee hardware upgrade to M3 Pro or role transition"
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg"
                rows={2}
              />
            </div>
            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                onClick={() => setReturningAsset(null)}
                className="px-3 py-1.5 text-slate-700 bg-white border border-slate-200 rounded-lg"
              >
                Cancel
              </button>
              <button
                onClick={handleReturnConfirm}
                className="px-4 py-1.5 font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg"
              >
                Confirm Return & Stock Available
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
