import React, { useState } from 'react';
import { db } from '../../db/storage';
import { useAuth } from '../../services/authContext';
import { CompanyProfile, AuditLog } from '../../types/hrms';
import { DataTable, Column } from '../common/DataTable';
import { ExportButton } from '../common/ExportButton';
import { Building, MapPin, Layers, History, Check, ShieldAlert, ShieldCheck } from 'lucide-react';
import { SecurityTestRunner } from './SecurityTestRunner';

export const CompanySettings: React.FC = () => {
  const { currentUser, canManageOrganization } = useAuth();
  const [activeTab, setActiveTab] = useState<'company' | 'branches' | 'departments' | 'audit' | 'security_audit'>('company');

  const [company, setCompany] = useState<CompanyProfile>(() => db.getCompanyProfile());
  const [saveSuccess, setSaveSuccess] = useState(false);

  const branches = db.getBranches();
  const departments = db.getDepartments();
  const auditLogs = db.getAuditLogs();

  if (!canManageOrganization()) {
    return (
      <div className="p-8 text-center bg-white rounded-xl border border-slate-200">
        <ShieldAlert className="h-8 w-8 text-rose-600 mx-auto mb-2" />
        <h3 className="text-base font-bold text-slate-900">Access Restricted</h3>
        <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
          Company organizational settings, legal entity registration, and audit streams are strictly restricted to HR Administrators.
        </p>
      </div>
    );
  }

  const handleSaveCompany = (e: React.FormEvent) => {
    e.preventDefault();
    db.updateCompanyProfile(company);
    db.logAudit({
      actorUserId: currentUser.id,
      actorName: currentUser.name,
      actorRole: 'hr_admin',
      action: 'UPDATE',
      module: 'SYSTEM',
      entityId: company.id,
      entityName: company.name,
      description: 'Updated organization profile and legal entity configuration'
    });
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const auditColumns: Column<AuditLog>[] = [
    {
      header: 'Timestamp',
      accessorKey: 'timestamp',
      sortable: true,
      cell: (log) => (
        <span className="font-mono text-slate-600 text-xs">
          {new Date(log.timestamp).toLocaleString()}
        </span>
      )
    },
    {
      header: 'Actor',
      accessorKey: 'actorName',
      sortable: true,
      cell: (log) => (
        <div>
          <span className="font-semibold text-slate-900">{log.actorName}</span>
          <span className="text-[10px] text-slate-400 block font-mono">Role: {log.actorRole}</span>
        </div>
      )
    },
    {
      header: 'Action',
      accessorKey: 'action',
      sortable: true,
      cell: (log) => (
        <span className="font-mono text-xs font-bold text-indigo-700 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded">
          {log.action}
        </span>
      )
    },
    {
      header: 'Module',
      accessorKey: 'module',
      sortable: true,
      cell: (log) => <span className="font-semibold text-slate-700">{log.module}</span>
    },
    {
      header: 'Description',
      accessorKey: 'description',
      cell: (log) => (
        <div>
          <span className="text-slate-800">{log.description}</span>
          {log.entityName && <span className="text-slate-400 block text-[11px]">Target: {log.entityName}</span>}
        </div>
      )
    }
  ];

  const exportAudit = auditLogs.map((l) => ({
    Timestamp: l.timestamp,
    Actor: l.actorName,
    Role: l.actorRole,
    Action: l.action,
    Module: l.module,
    Entity: l.entityName,
    Description: l.description
  }));

  return (
    <div className="space-y-6">
      {/* Settings Navigation */}
      <div className="flex items-center gap-1 bg-white p-2 rounded-xl border border-slate-200">
        <button
          onClick={() => setActiveTab('company')}
          className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors ${
            activeTab === 'company' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Building className="h-4 w-4" />
          <span>Company Profile</span>
        </button>
        <button
          onClick={() => setActiveTab('branches')}
          className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors ${
            activeTab === 'branches' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <MapPin className="h-4 w-4" />
          <span>Branches & Offices ({branches.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('departments')}
          className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors ${
            activeTab === 'departments' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Layers className="h-4 w-4" />
          <span>Departments ({departments.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('audit')}
          className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors ${
            activeTab === 'audit' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <History className="h-4 w-4" />
          <span>System Audit Log ({auditLogs.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('security_audit')}
          className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors ${
            activeTab === 'security_audit' ? 'bg-indigo-600 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <ShieldCheck className="h-4 w-4" />
          <span>Security & Privacy Audit (10 Tests)</span>
        </button>
      </div>

      {/* Tab: Company Profile */}
      {activeTab === 'company' && (
        <form onSubmit={handleSaveCompany} className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4 text-xs">
          <div className="pb-3 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Legal Entity & Tax Configuration</h3>
              <p className="text-slate-500 text-[11px] mt-0.5">Statutory parameters used in payroll slips and government compliance</p>
            </div>
            {saveSuccess && (
              <span className="text-emerald-700 font-semibold flex items-center gap-1 bg-emerald-50 px-2 py-1 rounded border border-emerald-200">
                <Check className="h-3.5 w-3.5" /> Saved Successfully
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-600 font-medium mb-1">Company Display Name</label>
              <input
                type="text"
                value={company.name}
                onChange={(e) => setCompany({ ...company, name: e.target.value })}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg"
                required
              />
            </div>
            <div>
              <label className="block text-slate-600 font-medium mb-1">Registered Legal Entity Name</label>
              <input
                type="text"
                value={company.legalEntity}
                onChange={(e) => setCompany({ ...company, legalEntity: e.target.value })}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg"
                required
              />
            </div>
            <div>
              <label className="block text-slate-600 font-medium mb-1">PAN / Tax ID Number</label>
              <input
                type="text"
                value={company.taxId}
                onChange={(e) => setCompany({ ...company, taxId: e.target.value })}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg font-mono uppercase"
                required
              />
            </div>
            <div>
              <label className="block text-slate-600 font-medium mb-1">Provident Fund (PF) Registration Code</label>
              <input
                type="text"
                value={company.pfRegistrationNumber}
                onChange={(e) => setCompany({ ...company, pfRegistrationNumber: e.target.value })}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg font-mono uppercase"
                required
              />
            </div>
            <div>
              <label className="block text-slate-600 font-medium mb-1">ESI Registration Number</label>
              <input
                type="text"
                value={company.esiRegistrationNumber}
                onChange={(e) => setCompany({ ...company, esiRegistrationNumber: e.target.value })}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg font-mono uppercase"
                required
              />
            </div>
            <div>
              <label className="block text-slate-600 font-medium mb-1">Operating Currency</label>
              <input
                type="text"
                value={`${company.currency} (${company.currencySymbol})`}
                disabled
                className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-500 font-mono"
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-slate-600 font-medium mb-1">Corporate Headquarters Address</label>
              <input
                type="text"
                value={company.address}
                onChange={(e) => setCompany({ ...company, address: e.target.value })}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg"
                required
              />
            </div>
          </div>

          <div className="flex justify-end pt-3 border-t border-slate-100">
            <button
              type="submit"
              className="px-4 py-2 font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-2xs transition-colors"
            >
              Save Organization Settings
            </button>
          </div>
        </form>
      )}

      {/* Tab: Branches */}
      {activeTab === 'branches' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          {branches.map((b) => (
            <div key={b.id} className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs space-y-2">
              <div className="flex justify-between items-center pb-2 border-b border-slate-100">
                <span className="font-bold text-slate-900">{b.name}</span>
                {b.isHeadquarters && (
                  <span className="text-[10px] font-semibold text-indigo-700 bg-indigo-50 border border-indigo-200 px-1.5 py-0.5 rounded">
                    HQ
                  </span>
                )}
              </div>
              <p className="text-slate-600">Code: <span className="font-mono text-slate-800">{b.code}</span></p>
              <p className="text-slate-600">City: <span className="font-semibold text-slate-800">{b.city}</span></p>
            </div>
          ))}
        </div>
      )}

      {/* Tab: Departments */}
      {activeTab === 'departments' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          {departments.map((d) => (
            <div key={d.id} className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs space-y-2">
              <div className="flex justify-between items-center pb-2 border-b border-slate-100">
                <span className="font-bold text-slate-900">{d.name}</span>
                <span className="font-mono text-slate-500 font-semibold">{d.code}</span>
              </div>
              <p className="text-slate-600 leading-relaxed">{d.description}</p>
            </div>
          ))}
        </div>
      )}

      {/* Tab: Audit Log */}
      {activeTab === 'audit' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Append-Only Audit Stream</h3>
              <p className="text-xs text-slate-500">Tamper-evident logs of approvals, salary finalized runs, and entity updates</p>
            </div>
            <ExportButton data={exportAudit} fileName="Orbyx_System_Audit_Log" />
          </div>

          <DataTable
            data={auditLogs}
            columns={auditColumns}
            searchPlaceholder="Filter audit records by actor, action, or module..."
          />
        </div>
      )}

      {/* Tab: Security & Privacy Audit */}
      {activeTab === 'security_audit' && (
        <SecurityTestRunner />
      )}
    </div>
  );
};
