import React, { useState } from 'react';
import { db } from '../../db/storage';
import { DataTable, Column } from '../common/DataTable';
import { ExportButton } from '../common/ExportButton';
import { StatCard } from '../common/StatCard';
import { BarChart3, Users, Calendar, CreditCard, Receipt, Clock } from 'lucide-react';

export const ReportsHub: React.FC = () => {
  const [reportType, setReportType] = useState<'headcount' | 'leave' | 'payroll' | 'expenses' | 'attendance'>('headcount');

  const employees = db.getEmployees();
  const departments = db.getDepartments();
  const leaveApps = db.getLeaveApplications();
  const leaveTypes = db.getLeaveTypes();
  const payrollItems = db.getPayrollLineItems();
  const claims = db.getExpenseClaims();
  const categories = db.getExpenseCategories();
  const attendance = db.getAttendanceRecords();

  // 1. Headcount by Department
  const headcountData = departments.map((dept) => {
    const deptEmps = employees.filter((e) => e.departmentId === dept.id);
    const active = deptEmps.filter((e) => e.status === 'Active' || e.status === 'Probation').length;
    return {
      Department: dept.name,
      Code: dept.code,
      TotalStaff: deptEmps.length,
      Active: active,
      OnLeave: deptEmps.filter((e) => e.status === 'On Leave').length
    };
  });

  // 2. Leave Utilization
  const leaveUtilData = leaveTypes.map((lt) => {
    const apps = leaveApps.filter((a) => a.leaveTypeId === lt.id && a.status === 'Approved');
    const totalDaysTaken = apps.reduce((acc, a) => acc + a.totalDays, 0);
    return {
      LeaveType: lt.name,
      Code: lt.code,
      Category: lt.isPaid ? 'Paid' : 'Unpaid',
      AnnualEntitlement: lt.annualEntitlement,
      TotalDaysTaken: totalDaysTaken,
      ApprovedRequests: apps.length
    };
  });

  // 3. Expense by Category
  const expenseSummaryData = categories.map((cat) => {
    const catClaims = claims.filter((c) => c.categoryId === cat.id);
    const totalClaimed = catClaims.reduce((acc, c) => acc + c.amount, 0);
    const reimbursed = catClaims.filter((c) => c.status === 'Reimbursed').reduce((acc, c) => acc + c.amount, 0);
    const pending = catClaims.filter((c) => c.status !== 'Reimbursed' && c.status !== 'Rejected').reduce((acc, c) => acc + c.amount, 0);
    return {
      Category: cat.name,
      Code: cat.code,
      MaxLimitPerClaim: `₹${cat.maxLimitPerClaim.toLocaleString()}`,
      TotalClaimsCount: catClaims.length,
      TotalAmountClaimed: `₹${totalClaimed.toLocaleString()}`,
      ReimbursedAmount: `₹${reimbursed.toLocaleString()}`,
      PendingAmount: `₹${pending.toLocaleString()}`
    };
  });

  return (
    <div className="space-y-6">
      {/* Selector Tabs */}
      <div className="bg-white p-3.5 rounded-xl border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1 bg-slate-100 p-1 rounded-lg">
          <button
            onClick={() => setReportType('headcount')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              reportType === 'headcount' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Headcount Report
          </button>
          <button
            onClick={() => setReportType('leave')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              reportType === 'leave' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Leave Utilization
          </button>
          <button
            onClick={() => setReportType('payroll')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              reportType === 'payroll' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Payroll Summary
          </button>
          <button
            onClick={() => setReportType('expenses')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              reportType === 'expenses' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Expense Categorization
          </button>
        </div>

        <ExportButton
          data={
            reportType === 'headcount'
              ? headcountData
              : reportType === 'leave'
              ? leaveUtilData
              : reportType === 'payroll'
              ? payrollItems
              : expenseSummaryData
          }
          fileName={`Orbyx_Report_${reportType}`}
        />
      </div>

      {/* Headcount Report */}
      {reportType === 'headcount' && (
        <DataTable
          data={headcountData}
          columns={[
            { header: 'Department', accessorKey: 'Department', sortable: true },
            { header: 'Code', accessorKey: 'Code', sortable: true },
            { header: 'Total Staff', accessorKey: 'TotalStaff', sortable: true },
            { header: 'Active Employees', accessorKey: 'Active', sortable: true },
            { header: 'On Leave Today', accessorKey: 'OnLeave', sortable: true }
          ]}
          searchPlaceholder="Filter departments..."
        />
      )}

      {/* Leave Utilization Report */}
      {reportType === 'leave' && (
        <DataTable
          data={leaveUtilData}
          columns={[
            { header: 'Leave Category', accessorKey: 'LeaveType', sortable: true },
            { header: 'Type', accessorKey: 'Category', sortable: true },
            { header: 'Annual Entitlement', accessorKey: 'AnnualEntitlement', sortable: true },
            { header: 'Total Days Utilized', accessorKey: 'TotalDaysTaken', sortable: true },
            { header: 'Approved Applications', accessorKey: 'ApprovedRequests', sortable: true }
          ]}
          searchPlaceholder="Filter leave types..."
        />
      )}

      {/* Payroll Summary Report */}
      {reportType === 'payroll' && (
        <DataTable
          data={payrollItems}
          columns={[
            { header: 'Employee', accessorKey: 'employeeName', sortable: true },
            { header: 'Department', accessorKey: 'departmentName', sortable: true },
            { header: 'Payable Days', accessorKey: 'payableDays', sortable: true },
            { header: 'Gross Earnings', accessorKey: 'grossEarnings', sortable: true, cell: (i) => `₹${i.grossEarnings.toLocaleString()}` },
            { header: 'PF Employee', accessorKey: 'pfEmployee', sortable: true, cell: (i) => `₹${i.pfEmployee.toLocaleString()}` },
            { header: 'TDS Tax', accessorKey: 'tdsWithholding', sortable: true, cell: (i) => `₹${i.tdsWithholding.toLocaleString()}` },
            { header: 'Net Pay', accessorKey: 'netPayable', sortable: true, cell: (i) => `₹${i.netPayable.toLocaleString()}` }
          ]}
          searchPlaceholder="Search payroll register..."
        />
      )}

      {/* Expense Summary Report */}
      {reportType === 'expenses' && (
        <DataTable
          data={expenseSummaryData}
          columns={[
            { header: 'Category Name', accessorKey: 'Category', sortable: true },
            { header: 'Code', accessorKey: 'Code', sortable: true },
            { header: 'Max Limit / Claim', accessorKey: 'MaxLimitPerClaim', sortable: true },
            { header: 'Claims Filed', accessorKey: 'TotalClaimsCount', sortable: true },
            { header: 'Total Claimed', accessorKey: 'TotalAmountClaimed', sortable: true },
            { header: 'Reimbursed Total', accessorKey: 'ReimbursedAmount', sortable: true },
            { header: 'Pending Payout', accessorKey: 'PendingAmount', sortable: true }
          ]}
          searchPlaceholder="Filter expense categories..."
        />
      )}
    </div>
  );
};
