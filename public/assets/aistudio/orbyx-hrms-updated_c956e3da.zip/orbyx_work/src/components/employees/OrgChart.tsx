import React from 'react';
import { db } from '../../db/storage';
import { Employee } from '../../types/hrms';
import { Users, ChevronRight, Briefcase } from 'lucide-react';

interface OrgChartProps {
  onSelectEmployee: (emp: Employee) => void;
}

export const OrgChart: React.FC<OrgChartProps> = ({ onSelectEmployee }) => {
  const employees = db.getEmployees();
  const departments = db.getDepartments();
  const designations = db.getDesignations();

  // Root leaders (no reporting manager or reports to EMP-001)
  const rootLeaders = employees.filter((e) => !e.reportingManagerId || e.id === 'EMP-001');

  const getDirectReports = (empId: string) => {
    return employees.filter((e) => e.reportingManagerId === empId && e.id !== empId);
  };

  const renderNode = (emp: Employee, depth = 0) => {
    const reports = getDirectReports(emp.id);
    const desig = designations.find((d) => d.id === emp.designationId);
    const dept = departments.find((d) => d.id === emp.departmentId);

    return (
      <div key={emp.id} className="relative pl-6 pb-4">
        {depth > 0 && (
          <div className="absolute left-0 top-6 w-5 h-px bg-slate-300" />
        )}
        {reports.length > 0 && depth > 0 && (
          <div className="absolute left-0 top-0 bottom-0 w-px bg-slate-200" />
        )}

        <div
          onClick={() => onSelectEmployee(emp)}
          className="inline-flex items-center gap-3 p-3 bg-white rounded-xl border border-slate-200 shadow-xs hover:border-indigo-400 hover:shadow-sm cursor-pointer transition-all min-w-72"
        >
          <img
            src={emp.avatarUrl}
            alt={emp.firstName}
            className="h-10 w-10 rounded-full object-cover ring-1 ring-slate-200"
          />
          <div className="flex-1 min-w-0 text-xs">
            <div className="flex items-center justify-between gap-1">
              <span className="font-bold text-slate-900 truncate">
                {emp.firstName} {emp.lastName}
              </span>
              <span className="text-[10px] font-mono text-slate-400">{emp.id}</span>
            </div>
            <p className="text-[11px] text-slate-600 truncate mt-0.5">{desig?.title || 'Staff'}</p>
            <div className="mt-1 flex items-center gap-2 text-[10px] text-slate-400">
              <span>{dept?.name}</span>
              {reports.length > 0 && (
                <>
                  <span>·</span>
                  <span className="font-semibold text-indigo-600">{reports.length} report{reports.length > 1 ? 's' : ''}</span>
                </>
              )}
            </div>
          </div>
        </div>

        {reports.length > 0 && (
          <div className="mt-3 pl-6 border-l border-slate-200 space-y-2">
            {reports.map((report) => renderNode(report, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
      <div className="pb-4 border-b border-slate-100 flex items-center justify-between mb-6">
        <div>
          <h3 className="text-sm font-bold text-slate-900">Organization Hierarchy Chart</h3>
          <p className="text-xs text-slate-500 mt-0.5">Visual reporting structure and department relationships</p>
        </div>
        <div className="text-xs text-slate-500 flex items-center gap-1.5">
          <Users className="h-4 w-4 text-indigo-600" />
          <span>{employees.length} Total Employees</span>
        </div>
      </div>

      <div className="overflow-x-auto py-2">
        {rootLeaders.map((leader) => renderNode(leader, 0))}
      </div>
    </div>
  );
};
