import React, { useState } from 'react';
import { db } from '../../db/storage';
import { Employee, BasicDirectoryEmployee } from '../../types/hrms';
import { useAuth } from '../../services/authContext';
import { permissionService } from '../../services/permissionService';
import { DataTable, Column } from '../common/DataTable';
import { ExportButton } from '../common/ExportButton';
import { EmployeeProfileModal } from './EmployeeProfileModal';
import { NewEmployeeModal } from './NewEmployeeModal';
import { OrgChart } from './OrgChart';
import { UserPlus, LayoutList, GitFork, Eye, ShieldCheck, Mail, Phone } from 'lucide-react';

export const EmployeeDirectory: React.FC = () => {
  const { currentUser, canManageOrganization } = useAuth();
  const [viewMode, setViewMode] = useState<'table' | 'orgChart'>('table');
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | BasicDirectoryEmployee | null>(null);
  const [isNewModalOpen, setIsNewModalOpen] = useState(false);
  const [selectedDeptFilter, setSelectedDeptFilter] = useState<string>('ALL');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('ALL');

  const departments = db.getDepartments();
  const designations = db.getDesignations();
  const branches = db.getBranches();

  const isRegularEmployee = currentUser.role === 'employee';
  const isManager = currentUser.role === 'senior_manager';
  const isHR = currentUser.role === 'hr_admin';

  // Retrieve authorized rows (sanitized strictly at service layer)
  const rawRows = permissionService.getAuthorizedDirectoryRows(currentUser);

  // Apply filters if permitted
  const filteredRows = rawRows.filter((r) => {
    if (isRegularEmployee) return true; // Filters hidden for regular employee
    if ('departmentId' in r && selectedDeptFilter !== 'ALL' && (r as Employee).departmentId !== selectedDeptFilter) return false;
    if ('status' in r && selectedStatusFilter !== 'ALL' && (r as Employee).status !== selectedStatusFilter) return false;
    return true;
  });

  // -------------------------------------------------------------------
  // COLUMNS CONFIGURATION ACCORDING TO ROLE & RELATIONSHIP
  // -------------------------------------------------------------------
  let columns: Column<any>[] = [];

  if (isRegularEmployee) {
    // REGULAR EMPLOYEES: STRICTLY ONLY Name, Official Mobile Number, Official Email, Photo
    columns = [
      {
        header: 'Colleague',
        accessorKey: 'firstName',
        sortable: true,
        cell: (emp: BasicDirectoryEmployee) => (
          <div className="flex items-center gap-3">
            <img
              src={emp.avatarUrl}
              alt={emp.firstName}
              className="h-10 w-10 rounded-full object-cover ring-1 ring-slate-200"
            />
            <div className="min-w-0">
              <div className="font-semibold text-slate-900 truncate">
                {emp.firstName} {emp.lastName}
              </div>
              <span className="text-[11px] text-slate-400">Company Colleague</span>
            </div>
          </div>
        )
      },
      {
        header: 'Official Mobile Number',
        accessorKey: 'officialPhone',
        sortable: true,
        cell: (emp: BasicDirectoryEmployee) => (
          <div className="flex items-center gap-1.5 font-mono text-slate-700 font-medium">
            <Phone className="h-3.5 w-3.5 text-slate-400" />
            <span>{emp.officialPhone}</span>
          </div>
        )
      },
      {
        header: 'Official Email Address',
        accessorKey: 'officialEmail',
        sortable: true,
        cell: (emp: BasicDirectoryEmployee) => (
          <div className="flex items-center gap-1.5 text-indigo-700">
            <Mail className="h-3.5 w-3.5 text-indigo-500" />
            <a href={`mailto:${emp.officialEmail}`} className="hover:underline">
              {emp.officialEmail}
            </a>
          </div>
        )
      },
      {
        header: 'Directory Access',
        cell: (emp: BasicDirectoryEmployee) => (
          <button
            onClick={() => setSelectedEmployee(emp)}
            className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-colors"
          >
            <Eye className="h-3.5 w-3.5" />
            <span>View Contact</span>
          </button>
        )
      }
    ];
  } else if (isManager) {
    // MANAGER VIEW: Direct reports show operational data; other colleagues show basic directory
    columns = [
      {
        header: 'Employee',
        accessorKey: 'firstName',
        sortable: true,
        cell: (r: any) => {
          const isDirectReport = r.isDirectReport;
          const desig = designations.find((d) => d.id === r.designationId);
          return (
            <div className="flex items-center gap-3">
              <img
                src={r.avatarUrl}
                alt={r.firstName}
                className="h-9 w-9 rounded-full object-cover ring-1 ring-slate-200"
              />
              <div className="min-w-0">
                <div className="font-semibold text-slate-900 truncate flex items-center gap-2">
                  <span>{r.firstName} {r.lastName}</span>
                  {isDirectReport && (
                    <span className="text-[10px] font-semibold text-indigo-700 bg-indigo-50 border border-indigo-200 px-1.5 py-0.2 rounded">
                      Direct Report
                    </span>
                  )}
                </div>
                <div className="text-[11px] text-slate-500 truncate">
                  {desig ? desig.title : 'Organization Colleague'}
                </div>
              </div>
            </div>
          );
        }
      },
      {
        header: 'Official Mobile',
        accessorKey: 'officialPhone',
        cell: (r: any) => <span className="font-mono text-slate-700">{r.officialPhone}</span>
      },
      {
        header: 'Official Email',
        accessorKey: 'officialEmail',
        cell: (r: any) => (
          <a href={`mailto:${r.officialEmail}`} className="text-indigo-700 hover:underline">
            {r.officialEmail}
          </a>
        )
      },
      {
        header: 'Reporting Scope',
        cell: (r: any) => (
          <span className="text-xs text-slate-600 font-medium">
            {r.isDirectReport ? 'Reporting to You' : 'External Department'}
          </span>
        )
      },
      {
        header: 'Actions',
        cell: (r: any) => (
          <button
            onClick={() => setSelectedEmployee(r)}
            className={`inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors ${
              r.isDirectReport
                ? 'text-indigo-700 bg-indigo-50 hover:bg-indigo-100'
                : 'text-slate-700 bg-slate-100 hover:bg-slate-200'
            }`}
          >
            <Eye className="h-3 w-3" />
            <span>{r.isDirectReport ? 'Team Profile' : 'View Contact'}</span>
          </button>
        )
      }
    ];
  } else {
    // HR ADMINISTRATOR: FULL ADMINISTRATIVE ATTRIBUTES
    columns = [
      {
        header: 'Employee',
        accessorKey: 'firstName',
        sortable: true,
        cell: (emp: Employee) => {
          const desig = designations.find((d) => d.id === emp.designationId);
          return (
            <div className="flex items-center gap-3">
              <img
                src={emp.avatarUrl}
                alt={emp.firstName}
                className="h-9 w-9 rounded-full object-cover ring-1 ring-slate-200"
              />
              <div className="min-w-0">
                <div className="font-semibold text-slate-900 truncate">
                  {emp.firstName} {emp.lastName}
                </div>
                <div className="text-[11px] text-slate-500 truncate flex items-center gap-1.5">
                  <span>{desig?.title || 'Staff'}</span>
                  <span>·</span>
                  <span className="font-mono text-slate-400">{emp.id}</span>
                </div>
              </div>
            </div>
          );
        }
      },
      {
        header: 'Department',
        accessorKey: 'departmentId',
        sortable: true,
        cell: (emp: Employee) => {
          const dept = departments.find((d) => d.id === emp.departmentId);
          return <span className="font-medium text-slate-800">{dept?.name || emp.departmentId}</span>;
        }
      },
      {
        header: 'Branch',
        accessorKey: 'branchId',
        sortable: true,
        cell: (emp: Employee) => {
          const br = branches.find((b) => b.id === emp.branchId);
          return <span className="text-slate-600">{br?.city || 'Bengaluru'}</span>;
        }
      },
      {
        header: 'Status',
        accessorKey: 'status',
        sortable: true,
        cell: (emp: Employee) => (
          <span
            className={`inline-flex items-center gap-1.5 text-xs font-medium ${
              emp.status === 'Active'
                ? 'text-emerald-700'
                : emp.status === 'On Leave'
                ? 'text-amber-700'
                : 'text-slate-600'
            }`}
          >
            <span
              className={`h-1.5 w-1.5 rounded-full ${
                emp.status === 'Active' ? 'bg-emerald-500' : emp.status === 'On Leave' ? 'bg-amber-500' : 'bg-slate-400'
              }`}
            />
            <span>{emp.status}</span>
          </span>
        )
      },
      {
        header: 'Official Contact',
        accessorKey: 'email',
        cell: (emp: Employee) => (
          <div className="text-[11px] space-y-0.5">
            <p className="text-slate-700">{emp.officialEmail || emp.email}</p>
            <p className="text-slate-400">{emp.officialPhone || emp.phone}</p>
          </div>
        )
      },
      {
        header: 'Joined',
        accessorKey: 'dateOfJoining',
        sortable: true,
        cell: (emp: Employee) => <span className="font-mono text-slate-600 text-xs">{emp.dateOfJoining}</span>
      },
      {
        header: 'Actions',
        cell: (emp: Employee) => (
          <button
            onClick={() => setSelectedEmployee(emp)}
            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-colors"
          >
            <Eye className="h-3 w-3" />
            <span>Profile</span>
          </button>
        )
      }
    ];
  }

  // Sanitized CSV Export generated directly via permissionService
  const exportData = permissionService.getAuthorizedDirectoryExport(currentUser);

  return (
    <div className="space-y-4">
      {/* Privacy Notice Banner for Regular Employees */}
      {isRegularEmployee && (
        <div className="p-3.5 bg-indigo-50/80 rounded-xl border border-indigo-100 flex items-center justify-between text-indigo-950">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="h-5 w-5 text-indigo-600 shrink-0" />
            <span className="text-xs font-medium">
              <span className="font-bold">Privacy-Protected Directory:</span> You can view colleagues' names, official mobile numbers, official email addresses, and profile photos. Confidential HR, salary, and personal details are restricted.
            </span>
          </div>
        </div>
      )}

      {/* View Switcher and Top Actions */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white p-3.5 rounded-xl border border-slate-200">
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
          <button
            onClick={() => setViewMode('table')}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              viewMode === 'table' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <LayoutList className="h-3.5 w-3.5" />
            <span>Directory Table</span>
          </button>
          {!isRegularEmployee && (
            <button
              onClick={() => setViewMode('orgChart')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                viewMode === 'orgChart' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <GitFork className="h-3.5 w-3.5" />
              <span>Hierarchy Chart</span>
            </button>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {viewMode === 'table' && (
            <>
              {/* Department & Status Filters (Enabled only for HR & Managers, hidden for regular employees to prevent information leakage) */}
              {!isRegularEmployee && (
                <>
                  <select
                    value={selectedDeptFilter}
                    onChange={(e) => setSelectedDeptFilter(e.target.value)}
                    className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-700"
                  >
                    <option value="ALL">All Departments</option>
                    {departments.map((d) => (
                      <option key={d.id} value={d.id}>{d.name}</option>
                    ))}
                  </select>

                  <select
                    value={selectedStatusFilter}
                    onChange={(e) => setSelectedStatusFilter(e.target.value)}
                    className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-700"
                  >
                    <option value="ALL">All Statuses</option>
                    <option value="Active">Active</option>
                    <option value="On Leave">On Leave</option>
                    <option value="Probation">Probation</option>
                  </select>
                </>
              )}

              {/* Sanitized CSV export */}
              <ExportButton data={exportData} fileName="Orbyx_Employee_Directory" />
            </>
          )}

          {canManageOrganization() && (
            <button
              onClick={() => setIsNewModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg shadow-2xs transition-colors"
            >
              <UserPlus className="h-3.5 w-3.5" />
              <span>Add Employee</span>
            </button>
          )}
        </div>
      </div>

      {/* Content: Table or OrgChart */}
      {viewMode === 'table' ? (
        <DataTable
          data={filteredRows}
          columns={columns}
          searchPlaceholder={isRegularEmployee ? "Search colleagues by name or official contact..." : "Search employees..."}
          searchFilterKey={(emp: any) => `${emp.firstName} ${emp.lastName} ${emp.officialEmail || emp.email || ''} ${emp.officialPhone || emp.phone || ''}`}
        />
      ) : (
        <OrgChart onSelectEmployee={(emp) => setSelectedEmployee(emp)} />
      )}

      {/* Profile Modal with Role-Based Scoped Rendering */}
      <EmployeeProfileModal
        employee={selectedEmployee}
        isOpen={!!selectedEmployee}
        onClose={() => setSelectedEmployee(null)}
      />

      {/* New Employee Modal */}
      <NewEmployeeModal
        isOpen={isNewModalOpen}
        onClose={() => setIsNewModalOpen(false)}
        onCreated={(newEmp) => setSelectedEmployee(newEmp)}
      />
    </div>
  );
};
