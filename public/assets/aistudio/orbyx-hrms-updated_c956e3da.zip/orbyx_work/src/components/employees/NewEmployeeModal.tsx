import React, { useState } from 'react';
import { Modal } from '../common/Modal';
import { db } from '../../db/storage';
import { hrmsService } from '../../services/hrmsService';
import { useAuth } from '../../services/authContext';
import { Employee, EmploymentType, EmploymentStatus } from '../../types/hrms';
import { Check, AlertCircle } from 'lucide-react';

interface NewEmployeeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreated: (emp: Employee) => void;
}

export const NewEmployeeModal: React.FC<NewEmployeeModalProps> = ({ isOpen, onClose, onCreated }) => {
  const { currentUser } = useAuth();

  const nextId = hrmsService.generateNextEmployeeId();
  const departments = db.getDepartments();
  const designations = db.getDesignations();
  const branches = db.getBranches();
  const shifts = db.getShifts();
  const managers = db.getEmployees();
  const structures = db.getSalaryStructures();

  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [dob, setDob] = useState('1996-01-01');
  const [gender, setGender] = useState<'Male' | 'Female' | 'Other'>('Male');
  const [bloodGroup, setBloodGroup] = useState('O+');
  const [address, setAddress] = useState('');

  // Emergency contact
  const [emName, setEmName] = useState('');
  const [emRelation, setEmRelation] = useState('Parent');
  const [emPhone, setEmPhone] = useState('');

  // Employment
  const [departmentId, setDepartmentId] = useState(departments[0]?.id || 'DEP-ENG');
  const [designationId, setDesignationId] = useState(designations[0]?.id || 'DES-JR-ENG');
  const [branchId, setBranchId] = useState(branches[0]?.id || 'BR-BLR');
  const [shiftId, setShiftId] = useState(shifts[0]?.id || 'SHIFT-GEN');
  const [reportingManagerId, setReportingManagerId] = useState(managers[1]?.id || 'EMP-002');
  const [employmentType, setEmploymentType] = useState<EmploymentType>('Permanent');
  const [dateOfJoining, setDateOfJoining] = useState(new Date().toISOString().split('T')[0]);

  // Financial & Statutory
  const [bankName, setBankName] = useState('HDFC Bank Ltd');
  const [accountNumber, setAccountNumber] = useState('');
  const [ifsc, setIfsc] = useState('HDFC0001234');
  const [panNumber, setPanNumber] = useState('');
  const [baseSalaryAnnual, setBaseSalaryAnnual] = useState(960000);
  const [salaryStructureId, setSalaryStructureId] = useState(structures[2]?.id || 'SS-JUNIOR');

  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!firstName || !lastName || !email || !phone || !accountNumber || !panNumber) {
      setError('Please complete all mandatory personal, contact, and banking fields.');
      return;
    }

    try {
      const created = hrmsService.createEmployee(
        {
          userId: `user_${firstName.toLowerCase()}_${Math.floor(Math.random() * 1000)}`,
          firstName,
          lastName,
          email,
          phone,
          avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
          dateOfBirth: dob,
          gender,
          bloodGroup,
          maritalStatus: 'Single',
          address: address || 'Indiranagar, Bengaluru',
          emergencyContact: {
            name: emName || `${firstName}'s Guardian`,
            relationship: emRelation,
            phone: emPhone || phone
          },
          departmentId,
          designationId,
          branchId,
          employmentType,
          status: 'Active',
          dateOfJoining,
          confirmationDate: employmentType === 'Permanent' ? '2026-10-01' : undefined,
          noticePeriodDays: 30,
          reportingManagerId,
          shiftId,
          bankDetails: {
            bankName,
            accountNumber,
            ifscOrRouting: ifsc,
            accountType: 'Savings'
          },
          panOrTaxNumber: panNumber.toUpperCase(),
          baseSalaryAnnual: Number(baseSalaryAnnual),
          salaryStructureId
        },
        currentUser.id,
        currentUser.name
      );

      onCreated(created);
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to create employee profile.');
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Create New Employee Profile"
      description={`Generated System ID: ${nextId} · Onboarding wizard`}
      maxWidth="3xl"
    >
      <form onSubmit={handleSubmit} className="space-y-4 text-xs">
        {error && (
          <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-lg flex items-center gap-2">
            <AlertCircle className="h-4 w-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Section 1: Basic Info */}
        <div className="p-3.5 bg-slate-50/75 rounded-xl border border-slate-200/80 space-y-3">
          <p className="font-semibold text-slate-900 border-b border-slate-200 pb-1">1. Personal & Contact Identity</p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-slate-600 font-medium mb-1">First Name *</label>
              <input
                type="text"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                placeholder="e.g. Rahul"
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg"
                required
              />
            </div>
            <div>
              <label className="block text-slate-600 font-medium mb-1">Last Name *</label>
              <input
                type="text"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                placeholder="e.g. Varma"
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg"
                required
              />
            </div>
            <div>
              <label className="block text-slate-600 font-medium mb-1">Work Email *</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="rahul.varma@orbyx.internal"
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg"
                required
              />
            </div>
            <div>
              <label className="block text-slate-600 font-medium mb-1">Mobile Phone *</label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+91 98111 22334"
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg"
                required
              />
            </div>
            <div>
              <label className="block text-slate-600 font-medium mb-1">Date of Birth</label>
              <input
                type="date"
                value={dob}
                onChange={(e) => setDob(e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-slate-600 font-medium mb-1">Gender</label>
              <select
                value={gender}
                onChange={(e) => setGender(e.target.value as any)}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg"
              >
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
            </div>
          </div>
        </div>

        {/* Section 2: Organization & Reporting */}
        <div className="p-3.5 bg-slate-50/75 rounded-xl border border-slate-200/80 space-y-3">
          <p className="font-semibold text-slate-900 border-b border-slate-200 pb-1">2. Department, Designation & Reporting</p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-slate-600 font-medium mb-1">Department</label>
              <select
                value={departmentId}
                onChange={(e) => setDepartmentId(e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg"
              >
                {departments.map((d) => (
                  <option key={d.id} value={d.id}>{d.name} ({d.code})</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-slate-600 font-medium mb-1">Designation</label>
              <select
                value={designationId}
                onChange={(e) => setDesignationId(e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg"
              >
                {designations.map((d) => (
                  <option key={d.id} value={d.id}>{d.title}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-slate-600 font-medium mb-1">Reporting Manager</label>
              <select
                value={reportingManagerId}
                onChange={(e) => setReportingManagerId(e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg"
              >
                {managers.map((m) => (
                  <option key={m.id} value={m.id}>{m.firstName} {m.lastName} ({m.id})</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-slate-600 font-medium mb-1">Branch Location</label>
              <select
                value={branchId}
                onChange={(e) => setBranchId(e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg"
              >
                {branches.map((b) => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-slate-600 font-medium mb-1">Employment Type</label>
              <select
                value={employmentType}
                onChange={(e) => setEmploymentType(e.target.value as any)}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg"
              >
                <option value="Permanent">Permanent</option>
                <option value="Contract">Contract</option>
                <option value="Probation">Probation</option>
                <option value="Intern">Intern</option>
              </select>
            </div>
            <div>
              <label className="block text-slate-600 font-medium mb-1">Work Shift</label>
              <select
                value={shiftId}
                onChange={(e) => setShiftId(e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg"
              >
                {shifts.map((s) => (
                  <option key={s.id} value={s.id}>{s.name} ({s.startTime} - {s.endTime})</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Section 3: Salary & Bank Details */}
        <div className="p-3.5 bg-slate-50/75 rounded-xl border border-slate-200/80 space-y-3">
          <p className="font-semibold text-slate-900 border-b border-slate-200 pb-1">3. Salary Structure & Banking Credentials</p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-slate-600 font-medium mb-1">Annual CTC (₹) *</label>
              <input
                type="number"
                value={baseSalaryAnnual}
                onChange={(e) => setBaseSalaryAnnual(Number(e.target.value))}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg font-mono"
                required
              />
            </div>
            <div>
              <label className="block text-slate-600 font-medium mb-1">Salary Structure</label>
              <select
                value={salaryStructureId}
                onChange={(e) => setSalaryStructureId(e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg"
              >
                {structures.map((s) => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-slate-600 font-medium mb-1">PAN / Tax ID *</label>
              <input
                type="text"
                value={panNumber}
                onChange={(e) => setPanNumber(e.target.value)}
                placeholder="ABCDE1234F"
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg font-mono uppercase"
                required
              />
            </div>
            <div>
              <label className="block text-slate-600 font-medium mb-1">Bank Name</label>
              <input
                type="text"
                value={bankName}
                onChange={(e) => setBankName(e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg"
                required
              />
            </div>
            <div>
              <label className="block text-slate-600 font-medium mb-1">Account Number *</label>
              <input
                type="text"
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value)}
                placeholder="50100498761234"
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg font-mono"
                required
              />
            </div>
            <div>
              <label className="block text-slate-600 font-medium mb-1">IFSC Code *</label>
              <input
                type="text"
                value={ifsc}
                onChange={(e) => setIfsc(e.target.value)}
                placeholder="HDFC0001234"
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg font-mono uppercase"
                required
              />
            </div>
          </div>
        </div>

        {/* Buttons */}
        <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 shadow-2xs transition-colors flex items-center gap-1.5"
          >
            <Check className="h-4 w-4" />
            <span>Create & Onboard Employee</span>
          </button>
        </div>
      </form>
    </Modal>
  );
};
