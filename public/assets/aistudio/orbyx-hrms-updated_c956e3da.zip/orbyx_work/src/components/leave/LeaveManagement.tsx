import React, { useState } from 'react';
import { db } from '../../db/storage';
import { LeaveApplication } from '../../types/hrms';
import { useAuth } from '../../services/authContext';
import { hrmsService } from '../../services/hrmsService';
import { DataTable, Column } from '../common/DataTable';
import { ExportButton } from '../common/ExportButton';
import { StatCard } from '../common/StatCard';
import { ApplyLeaveModal } from './ApplyLeaveModal';
import { AbsenceCalendar } from './AbsenceCalendar';
import {
  CalendarDays,
  CalendarCheck,
  CalendarX,
  Plus,
  Check,
  X,
  Calendar,
  Layers,
  Sparkles
} from 'lucide-react';

export const LeaveManagement: React.FC = () => {
  const { currentUser, canApproveRequestFor } = useAuth();
  const [activeTab, setActiveTab] = useState<'applications' | 'approvals' | 'calendar' | 'policies' | 'holidays'>('applications');
  const [isApplyModalOpen, setIsApplyModalOpen] = useState(false);
  const [commentModalApp, setCommentModalApp] = useState<{ id: string; decision: 'Approved' | 'Rejected' } | null>(null);
  const [decisionComments, setDecisionComments] = useState('');

  const applications = db.getLeaveApplications();
  const leaveTypes = db.getLeaveTypes();
  const employees = db.getEmployees();
  const holidays = db.getHolidays();

  // Scope filter:
  // HR Admin sees all; Manager sees all or direct reports; Employee sees their own
  const visibleApplications = applications.filter((app) => {
    if (currentUser.role === 'hr_admin') return true;
    if (currentUser.role === 'senior_manager') {
      const emp = employees.find((e) => e.id === app.employeeId);
      return emp?.reportingManagerId === currentUser.employeeId || app.employeeId === currentUser.employeeId;
    }
    return app.employeeId === currentUser.employeeId;
  });

  const pendingApprovals = applications.filter((app) => {
    if (app.status !== 'Pending Approval') return false;
    return canApproveRequestFor(app.employeeId);
  });

  const approvedCount = visibleApplications.filter((a) => a.status === 'Approved').length;
  const rejectedCount = visibleApplications.filter((a) => a.status === 'Rejected').length;

  const handleDecisionConfirm = () => {
    if (!commentModalApp) return;
    hrmsService.decideLeave(
      commentModalApp.id,
      commentModalApp.decision,
      decisionComments,
      currentUser.id,
      currentUser.name
    );
    setCommentModalApp(null);
    setDecisionComments('');
  };

  const columns: Column<LeaveApplication>[] = [
    {
      header: 'Applicant',
      accessorKey: 'employeeId',
      sortable: true,
      cell: (app) => {
        const emp = employees.find((e) => e.id === app.employeeId);
        return (
          <div className="flex items-center gap-2.5">
            <img
              src={emp?.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'}
              alt={emp?.firstName || ''}
              className="h-8 w-8 rounded-full object-cover"
            />
            <div>
              <p className="font-semibold text-slate-900">{emp ? `${emp.firstName} ${emp.lastName}` : app.employeeId}</p>
              <p className="text-[11px] text-slate-500 font-mono">{app.employeeId}</p>
            </div>
          </div>
        );
      }
    },
    {
      header: 'Leave Type',
      accessorKey: 'leaveTypeId',
      sortable: true,
      cell: (app) => {
        const lt = leaveTypes.find((l) => l.id === app.leaveTypeId);
        return (
          <div>
            <span className="font-medium text-slate-800">{lt?.name || app.leaveTypeId}</span>
            <span className="text-[11px] text-slate-400 block">{lt?.isPaid ? 'Paid' : 'Unpaid (LOP)'}</span>
          </div>
        );
      }
    },
    {
      header: 'Duration',
      accessorKey: 'totalDays',
      sortable: true,
      cell: (app) => (
        <div>
          <span className="font-bold text-slate-900 font-mono">{app.totalDays} day{app.totalDays !== 1 ? 's' : ''}</span>
          <span className="text-[11px] text-slate-500 block">
            {app.startDate} to {app.endDate}
          </span>
        </div>
      )
    },
    {
      header: 'Reason',
      accessorKey: 'reason',
      cell: (app) => (
        <div className="max-w-xs">
          <p className="text-slate-700 truncate">{app.reason}</p>
          {app.attachmentName && (
            <p className="text-[10px] text-indigo-600 truncate mt-0.5">Attachment: {app.attachmentName}</p>
          )}
        </div>
      )
    },
    {
      header: 'Status',
      accessorKey: 'status',
      sortable: true,
      cell: (app) => (
        <span
          className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-xs font-medium ${
            app.status === 'Approved'
              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
              : app.status === 'Rejected'
              ? 'bg-rose-50 text-rose-700 border border-rose-200'
              : 'bg-amber-50 text-amber-700 border border-amber-200'
          }`}
        >
          {app.status}
        </span>
      )
    },
    {
      header: 'Actions',
      cell: (app) => {
        const canApprove = app.status === 'Pending Approval' && canApproveRequestFor(app.employeeId);
        if (!canApprove) {
          return app.decidedAt ? (
            <span className="text-[10px] text-slate-400">
              {app.approvalComments || 'Decided'}
            </span>
          ) : null;
        }

        return (
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setCommentModalApp({ id: app.id, decision: 'Approved' })}
              className="p-1.5 rounded-md bg-emerald-600 hover:bg-emerald-700 text-white transition-colors"
              title="Approve"
            >
              <Check className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={() => setCommentModalApp({ id: app.id, decision: 'Rejected' })}
              className="p-1.5 rounded-md bg-rose-600 hover:bg-rose-700 text-white transition-colors"
              title="Reject"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        );
      }
    }
  ];

  const exportData = visibleApplications.map((a) => ({
    ApplicationID: a.id,
    EmployeeID: a.employeeId,
    LeaveType: leaveTypes.find((l) => l.id === a.leaveTypeId)?.name || '',
    StartDate: a.startDate,
    EndDate: a.endDate,
    TotalDays: a.totalDays,
    Reason: a.reason,
    Status: a.status,
    AppliedAt: a.appliedAt
  }));

  return (
    <div className="space-y-6">
      {/* Top Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Applications"
          value={visibleApplications.length}
          subtitle="Within accessible scope"
          icon={CalendarDays}
          badge="Ledger Active"
          badgeColor="slate"
        />
        <StatCard
          title="Pending Approvals"
          value={pendingApprovals.length}
          subtitle="Waiting for your review"
          icon={CalendarCheck}
          badge={pendingApprovals.length > 0 ? 'Action Needed' : 'Cleared'}
          badgeColor={pendingApprovals.length > 0 ? 'amber' : 'emerald'}
          onClick={() => setActiveTab('approvals')}
        />
        <StatCard
          title="Approved Requests"
          value={approvedCount}
          subtitle="Deducted from balance"
          icon={Check}
          badge="Verified"
          badgeColor="emerald"
        />
        <StatCard
          title="Upcoming Holidays"
          value={holidays.length}
          subtitle="Year 2026 Calendar"
          icon={Calendar}
          badge="12 Declared"
          badgeColor="blue"
          onClick={() => setActiveTab('holidays')}
        />
      </div>

      {/* Tab Switcher & Top Actions */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white p-3.5 rounded-xl border border-slate-200">
        <div className="flex flex-wrap items-center gap-1 bg-slate-100 p-1 rounded-lg">
          <button
            onClick={() => setActiveTab('applications')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'applications' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Applications ({visibleApplications.length})
          </button>
          {pendingApprovals.length > 0 && (
            <button
              onClick={() => setActiveTab('approvals')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                activeTab === 'approvals' ? 'bg-white text-rose-700 shadow-xs' : 'text-rose-600 hover:text-rose-800'
              }`}
            >
              Action Queue ({pendingApprovals.length})
            </button>
          )}
          <button
            onClick={() => setActiveTab('calendar')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'calendar' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Absence Calendar
          </button>
          <button
            onClick={() => setActiveTab('policies')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'policies' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Leave Policies ({leaveTypes.length})
          </button>
          <button
            onClick={() => setActiveTab('holidays')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'holidays' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Holiday Calendar
          </button>
        </div>

        <div className="flex items-center gap-2">
          <ExportButton data={exportData} fileName="Orbyx_Leave_Ledger" />
          <button
            onClick={() => setIsApplyModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg shadow-2xs transition-colors"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>Apply for Leave</span>
          </button>
        </div>
      </div>

      {/* Tab 1: Applications */}
      {activeTab === 'applications' && (
        <DataTable
          data={visibleApplications}
          columns={columns}
          searchPlaceholder="Search leave requests by employee or reason..."
        />
      )}

      {/* Tab 2: Pending Approvals */}
      {activeTab === 'approvals' && (
        <DataTable
          data={pendingApprovals}
          columns={columns}
          searchPlaceholder="Filter pending approvals..."
          emptyMessage="No approvals waiting in your queue."
        />
      )}

      {/* Tab 3: Absence Calendar */}
      {activeTab === 'calendar' && <AbsenceCalendar />}

      {/* Tab 4: Policies */}
      {activeTab === 'policies' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {leaveTypes.map((type) => (
            <div key={type.id} className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">{type.name}</h4>
                  <p className="text-xs text-slate-500">{type.description}</p>
                </div>
                <span className={`px-2 py-0.5 rounded text-xs font-mono font-bold ${
                  type.isPaid ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-rose-50 text-rose-700 border border-rose-200'
                }`}>
                  {type.code}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs text-slate-600">
                <div><span className="text-slate-400 block">Annual Entitlement:</span><span className="font-semibold text-slate-800">{type.annualEntitlement} days / year</span></div>
                <div><span className="text-slate-400 block">Carry Forward Limit:</span><span className="font-semibold text-slate-800">{type.carryForwardLimit} days</span></div>
                <div><span className="text-slate-400 block">Max Consecutive:</span><span className="font-semibold text-slate-800">{type.maxConsecutiveDays} days</span></div>
                <div><span className="text-slate-400 block">Half-Day Allowed:</span><span className="font-semibold text-slate-800">{type.allowsHalfDay ? 'Yes' : 'No'}</span></div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 5: Holidays */}
      {activeTab === 'holidays' && (
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="pb-3 border-b border-slate-100 mb-4 flex justify-between items-center">
            <div>
              <h3 className="text-sm font-bold text-slate-900">2026 Official Company Holidays</h3>
              <p className="text-xs text-slate-500">Working days are automatically calculated excluding these dates</p>
            </div>
            <span className="text-xs font-semibold text-indigo-700 bg-indigo-50 px-2 py-1 rounded">12 Days</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
            {holidays.map((h) => (
              <div key={h.id} className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex justify-between items-center">
                <div>
                  <p className="font-semibold text-slate-900">{h.name}</p>
                  <p className="text-[11px] text-slate-500 font-mono">{h.date}</p>
                </div>
                <span className={`text-[10px] px-2 py-0.5 rounded font-medium ${
                  h.isOptional ? 'bg-amber-100 text-amber-800' : 'bg-slate-200 text-slate-700'
                }`}>
                  {h.isOptional ? 'Optional' : 'Public'}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Decision Comments Modal */}
      {commentModalApp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-xl border border-slate-200 space-y-4">
            <h4 className="text-base font-bold text-slate-900">
              {commentModalApp.decision === 'Approved' ? 'Approve Leave Request' : 'Reject Leave Request'}
            </h4>
            <p className="text-xs text-slate-600">
              Please enter review notes or justification. The applicant will be notified immediately.
            </p>
            <textarea
              value={decisionComments}
              onChange={(e) => setDecisionComments(e.target.value)}
              placeholder="e.g. Approved. Please ensure project sprint handover before departure..."
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
              rows={3}
              required
            />
            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                onClick={() => setCommentModalApp(null)}
                className="px-3 py-1.5 text-xs text-slate-700 bg-white border border-slate-200 rounded-lg"
              >
                Cancel
              </button>
              <button
                onClick={handleDecisionConfirm}
                className={`px-4 py-1.5 text-xs font-semibold text-white rounded-lg ${
                  commentModalApp.decision === 'Approved' ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-rose-600 hover:bg-rose-700'
                }`}
              >
                Confirm {commentModalApp.decision}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Apply Leave Modal */}
      <ApplyLeaveModal
        isOpen={isApplyModalOpen}
        onClose={() => setIsApplyModalOpen(false)}
      />
    </div>
  );
};
