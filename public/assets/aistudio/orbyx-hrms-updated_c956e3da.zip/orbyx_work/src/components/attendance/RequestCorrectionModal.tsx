import React, { useState } from 'react';
import { Modal } from '../common/Modal';
import { hrmsService } from '../../services/hrmsService';
import { useAuth } from '../../services/authContext';
import { AlertCircle, Check } from 'lucide-react';

interface RequestCorrectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

export const RequestCorrectionModal: React.FC<RequestCorrectionModalProps> = ({
  isOpen,
  onClose,
  onSuccess
}) => {
  const { currentUser } = useAuth();
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [requestedCheckIn, setRequestedCheckIn] = useState('09:30');
  const [requestedCheckOut, setRequestedCheckOut] = useState('18:30');
  const [reason, setReason] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) {
      setError('Please provide a legitimate reason for the attendance correction request.');
      return;
    }

    hrmsService.submitAttendanceCorrection(
      {
        employeeId: currentUser.employeeId,
        date,
        requestedCheckIn,
        requestedCheckOut,
        reason
      },
      currentUser.id,
      currentUser.name
    );

    onSuccess?.();
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Request Attendance Correction"
      description={`Submitting as ${currentUser.name} (ID: ${currentUser.employeeId})`}
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4 text-xs">
        {error && (
          <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-lg flex items-center gap-2">
            <AlertCircle className="h-4 w-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <div>
          <label className="block text-slate-600 font-medium mb-1">Attendance Date *</label>
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg font-mono"
            required
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-slate-600 font-medium mb-1">Correct Check-In (HH:MM) *</label>
            <input
              type="time"
              value={requestedCheckIn}
              onChange={(e) => setRequestedCheckIn(e.target.value)}
              className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg font-mono"
              required
            />
          </div>
          <div>
            <label className="block text-slate-600 font-medium mb-1">Correct Check-Out (HH:MM) *</label>
            <input
              type="time"
              value={requestedCheckOut}
              onChange={(e) => setRequestedCheckOut(e.target.value)}
              className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg font-mono"
              required
            />
          </div>
        </div>

        <div>
          <label className="block text-slate-600 font-medium mb-1">Reason / Explanation *</label>
          <textarea
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            rows={3}
            placeholder="e.g. Forgot to punch out due to late emergency client deployment or biometric scanner network downtime..."
            className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg"
            required
          />
        </div>

        <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-2xs transition-colors flex items-center gap-1.5"
          >
            <Check className="h-4 w-4" />
            <span>Submit Correction</span>
          </button>
        </div>
      </form>
    </Modal>
  );
};
