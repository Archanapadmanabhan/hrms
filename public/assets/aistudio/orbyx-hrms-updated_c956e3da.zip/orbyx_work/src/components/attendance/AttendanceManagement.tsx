import React, { useState } from 'react';
import { db } from '../../db/storage';
import { AttendanceRecord, AttendanceCorrectionRequest } from '../../types/hrms';
import { useAuth } from '../../services/authContext';
import { hrmsService } from '../../services/hrmsService';
import { DataTable, Column } from '../common/DataTable';
import { ExportButton } from '../common/ExportButton';
import { StatCard } from '../common/StatCard';
import { RequestCorrectionModal } from './RequestCorrectionModal';
import {
  Clock,
  LogIn,
  LogOut,
  CheckCircle2,
  AlertTriangle,
  Plus,
  Check,
  X,
  Layers
} from 'lucide-react';

export const AttendanceManagement: React.FC = () => {
  const { currentUser, canApproveRequestFor } = useAuth();
  const [activeTab, setActiveTab] = useState<'records' | 'corrections' | 'shifts'>('records');
  const [isCorrectionModalOpen, setIsCorrectionModalOpen] = useState(false);

  const [reviewCorr, setReviewCorr] = useState<{ id: string; decision: 'Approved' | 'Rejected' } | null>(null);
  const [reviewComments, setReviewComments] = useState('');

  const records = db.getAttendanceRecords();
  const corrections = db.getCorrectionRequests();
  const shifts = db.getShifts();
  const employees = db.getEmployees();

  const isHR = currentUser.role === 'hr_admin';

  // Scope: HR sees all; Manager sees team + own; Employee sees own
  const visibleRecords = records.filter((r) => {
    if (isHR) return true;
    if (currentUser.role === 'senior_manager') {
      const emp = employees.find((e) => e.id === r.employeeId);
      return emp?.reportingManagerId === currentUser.employeeId || r.employeeId === currentUser.employeeId;
    }
    return r.employeeId === currentUser.employeeId;
  });

  const pendingCorrections = corrections.filter((c) => {
    if (c.status !== 'Pending') return false;
    return canApproveRequestFor(c.employeeId);
  });

  const todayStr = new Date().toISOString().split('T')[0];
  const myTodayRecord = records.find(
    (r) => r.employeeId === currentUser.employeeId && r.date === todayStr
  );

  const handlePunch = (type: 'check-in' | 'check-out') => {
    hrmsService.punchAttendance(currentUser.employeeId, type, currentUser.id, currentUser.name);
  };

  const handleCorrectionDecision = () => {
    if (!reviewCorr) return;
    hrmsService.decideAttendanceCorrection(
      reviewCorr.id,
      reviewCorr.decision,
      reviewComments,
      currentUser.id,
      currentUser.name
    );
    setReviewCorr(null);
    setReviewComments('');
  };

  const recordColumns: Column<AttendanceRecord>[] = [
    {
      header: 'Employee',
      accessorKey: 'employeeId',
      sortable: true,
      cell: (rec) => {
        const emp = employees.find((e) => e.id === rec.employeeId);
        return (
          <div className="flex items-center gap-2">
            <img
              src={emp?.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'}
              alt=""
              className="h-7 w-7 rounded-full object-cover"
            />
            <div>
              <p className="font-semibold text-slate-900">{emp ? `${emp.firstName} ${emp.lastName}` : rec.employeeId}</p>
              <p className="text-[10px] text-slate-400 font-mono">{rec.employeeId}</p>
            </div>
          </div>
        );
      }
    },
    {
      header: 'Date',
      accessorKey: 'date',
      sortable: true,
      cell: (rec) => <span className="font-mono text-slate-700 font-medium">{rec.date}</span>
    },
    {
      header: 'Check-In',
      accessorKey: 'checkInTime',
      sortable: true,
      cell: (rec) => (
        <div>
          <span className="font-mono font-bold text-slate-900">{rec.checkInTime || '--:--'}</span>
          {rec.isLate && (
            <span className="text-[10px] text-rose-600 block font-medium">+{rec.lateMinutes}m Late</span>
          )}
        </div>
      )
    },
    {
      header: 'Check-Out',
      accessorKey: 'checkOutTime',
      sortable: true,
      cell: (rec) => (
        <span className="font-mono font-bold text-slate-900">{rec.checkOutTime || 'Active'}</span>
      )
    },
    {
      header: 'Hours Worked',
      accessorKey: 'totalHoursWorked',
      sortable: true,
      cell: (rec) => (
        <div>
          <span className="font-mono font-bold text-slate-900">{rec.totalHoursWorked} hrs</span>
          {rec.overtimeHours > 0 && (
            <span className="text-[10px] text-indigo-600 block">+{rec.overtimeHours}h OT</span>
          )}
        </div>
      )
    },
    {
      header: 'Status',
      accessorKey: 'status',
      sortable: true,
      cell: (rec) => (
        <span
          className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
            rec.status === 'Present'
              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
              : rec.status === 'Late'
              ? 'bg-amber-50 text-amber-700 border border-amber-200'
              : rec.status === 'On Leave'
              ? 'bg-blue-50 text-blue-700 border border-blue-200'
              : 'bg-slate-100 text-slate-600'
          }`}
        >
          {rec.status}
        </span>
      )
    },
    {
      header: 'Source',
      accessorKey: 'source',
      cell: (rec) => <span className="text-[11px] text-slate-500">{rec.source}</span>
    }
  ];

  const corrColumns: Column<AttendanceCorrectionRequest>[] = [
    {
      header: 'Employee',
      accessorKey: 'employeeId',
      sortable: true,
      cell: (req) => {
        const emp = employees.find((e) => e.id === req.employeeId);
        return <span className="font-semibold text-slate-900">{emp ? `${emp.firstName} ${emp.lastName}` : req.employeeId}</span>;
      }
    },
    {
      header: 'Date',
      accessorKey: 'date',
      sortable: true,
      cell: (req) => <span className="font-mono">{req.date}</span>
    },
    {
      header: 'Requested Punches',
      cell: (req) => (
        <span className="font-mono font-medium text-slate-800">
          In: {req.requestedCheckIn} | Out: {req.requestedCheckOut}
        </span>
      )
    },
    {
      header: 'Reason',
      accessorKey: 'reason',
      cell: (req) => <span className="text-slate-600">{req.reason}</span>
    },
    {
      header: 'Status',
      accessorKey: 'status',
      sortable: true,
      cell: (req) => (
        <span
          className={`px-2 py-0.5 rounded text-xs font-medium ${
            req.status === 'Approved'
              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
              : req.status === 'Rejected'
              ? 'bg-rose-50 text-rose-700 border border-rose-200'
              : 'bg-amber-50 text-amber-700 border border-amber-200'
          }`}
        >
          {req.status}
        </span>
      )
    },
    {
      header: 'Actions',
      cell: (req) => {
        if (req.status !== 'Pending' || !canApproveRequestFor(req.employeeId)) {
          return null;
        }
        return (
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setReviewCorr({ id: req.id, decision: 'Approved' })}
              className="p-1.5 bg-emerald-600 text-white rounded hover:bg-emerald-700 transition-colors"
              title="Approve"
            >
              <Check className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={() => setReviewCorr({ id: req.id, decision: 'Rejected' })}
              className="p-1.5 bg-rose-600 text-white rounded hover:bg-rose-700 transition-colors"
              title="Reject"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        );
      }
    }
  ];

  const exportData = visibleRecords.map((r) => ({
    EmployeeID: r.employeeId,
    Date: r.date,
    CheckIn: r.checkInTime || '',
    CheckOut: r.checkOutTime || '',
    TotalHours: r.totalHoursWorked,
    Status: r.status,
    IsLate: r.isLate ? 'Yes' : 'No',
    LateMinutes: r.lateMinutes,
    Source: r.source
  }));

  return (
    <div className="space-y-6">
      {/* Live Punch Card for Current User */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="h-12 w-12 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600">
            <Clock className="h-6 w-6" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900">Today's Attendance Station ({todayStr})</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Shift: <span className="font-semibold text-slate-700">General Day Shift (09:30 - 18:30)</span> · 15 min grace period
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {!myTodayRecord?.checkInTime ? (
            <button
              onClick={() => handlePunch('check-in')}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow-2xs transition-colors"
            >
              <LogIn className="h-4 w-4" />
              <span>Record Web Check-In</span>
            </button>
          ) : !myTodayRecord?.checkOutTime ? (
            <div className="flex items-center gap-3">
              <span className="text-xs text-slate-700">
                Checked in at <span className="font-mono font-bold text-slate-900">{myTodayRecord.checkInTime}</span>
              </span>
              <button
                onClick={() => handlePunch('check-out')}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg transition-colors"
              >
                <LogOut className="h-3.5 w-3.5" />
                <span>Check Out</span>
              </button>
            </div>
          ) : (
            <span className="text-xs text-emerald-800 font-semibold bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-lg flex items-center gap-1.5">
              <CheckCircle2 className="h-4 w-4 text-emerald-600" />
              <span>Shift Complete ({myTodayRecord.totalHoursWorked} hrs)</span>
            </span>
          )}

          <button
            onClick={() => setIsCorrectionModalOpen(true)}
            className="px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors"
          >
            Request Correction
          </button>
        </div>
      </div>

      {/* Tabs and Actions Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white p-3.5 rounded-xl border border-slate-200">
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
          <button
            onClick={() => setActiveTab('records')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'records' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Timesheet Records ({visibleRecords.length})
          </button>
          <button
            onClick={() => setActiveTab('corrections')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'corrections' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Corrections Queue ({pendingCorrections.length})
          </button>
          <button
            onClick={() => setActiveTab('shifts')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'shifts' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Configured Shifts ({shifts.length})
          </button>
        </div>

        <div className="flex items-center gap-2">
          <ExportButton data={exportData} fileName="Orbyx_Attendance_Log" />
        </div>
      </div>

      {/* Content: Records */}
      {activeTab === 'records' && (
        <DataTable
          data={visibleRecords}
          columns={recordColumns}
          searchPlaceholder="Search punches by employee or date..."
        />
      )}

      {/* Content: Corrections */}
      {activeTab === 'corrections' && (
        <DataTable
          data={isHR ? corrections : pendingCorrections}
          columns={corrColumns}
          searchPlaceholder="Filter correction requests..."
          emptyMessage="No pending attendance correction requests."
        />
      )}

      {/* Content: Shifts */}
      {activeTab === 'shifts' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          {shifts.map((s) => (
            <div key={s.id} className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs space-y-3">
              <div className="flex justify-between items-center pb-2 border-b border-slate-100">
                <span className="font-bold text-slate-900">{s.name}</span>
                <span className="font-mono text-xs text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">{s.code}</span>
              </div>
              <div className="space-y-1.5 text-slate-600">
                <div className="flex justify-between"><span className="text-slate-400">Timings:</span><span className="font-mono font-medium">{s.startTime} - {s.endTime}</span></div>
                <div className="flex justify-between"><span className="text-slate-400">Total Duration:</span><span>{s.totalWorkingHours} hours</span></div>
                <div className="flex justify-between"><span className="text-slate-400">Grace Period:</span><span>{s.gracePeriodMinutes} mins</span></div>
                <div className="flex justify-between"><span className="text-slate-400">Break Duration:</span><span>{s.breakDurationMinutes} mins</span></div>
                <div className="flex justify-between"><span className="text-slate-400">Weekly Offs:</span><span>Saturday, Sunday</span></div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Decision Modal */}
      {reviewCorr && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-xl border border-slate-200 space-y-4 text-xs">
            <h4 className="text-base font-bold text-slate-900">
              {reviewCorr.decision === 'Approved' ? 'Approve Attendance Correction' : 'Reject Attendance Correction'}
            </h4>
            <p className="text-slate-600">
              Approved corrections will overwrite the timesheet entry and resolve attendance exceptions.
            </p>
            <textarea
              value={reviewComments}
              onChange={(e) => setReviewComments(e.target.value)}
              placeholder="e.g. Verified with Jira commit timestamps..."
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg"
              rows={3}
            />
            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                onClick={() => setReviewCorr(null)}
                className="px-3 py-1.5 text-slate-700 bg-white border border-slate-200 rounded-lg"
              >
                Cancel
              </button>
              <button
                onClick={handleCorrectionDecision}
                className={`px-4 py-1.5 font-semibold text-white rounded-lg ${
                  reviewCorr.decision === 'Approved' ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-rose-600 hover:bg-rose-700'
                }`}
              >
                Confirm {reviewCorr.decision}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Request Correction Modal */}
      <RequestCorrectionModal
        isOpen={isCorrectionModalOpen}
        onClose={() => setIsCorrectionModalOpen(false)}
      />
    </div>
  );
};
