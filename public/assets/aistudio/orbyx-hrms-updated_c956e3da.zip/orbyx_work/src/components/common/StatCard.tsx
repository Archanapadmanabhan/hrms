import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  badge?: string;
  badgeColor?: 'emerald' | 'amber' | 'rose' | 'blue' | 'indigo' | 'slate';
  onClick?: () => void;
}

export const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  subtitle,
  icon: Icon,
  badge,
  badgeColor = 'slate',
  onClick
}) => {
  const getBadgeClass = () => {
    switch (badgeColor) {
      case 'emerald':
        return 'text-emerald-700 bg-emerald-50 border border-emerald-200';
      case 'amber':
        return 'text-amber-700 bg-amber-50 border border-amber-200';
      case 'rose':
        return 'text-rose-700 bg-rose-50 border border-rose-200';
      case 'blue':
        return 'text-blue-700 bg-blue-50 border border-blue-200';
      case 'indigo':
        return 'text-indigo-700 bg-indigo-50 border border-indigo-200';
      default:
        return 'text-slate-600 bg-slate-100 border border-slate-200';
    }
  };

  return (
    <div
      onClick={onClick}
      className={`bg-white rounded-xl border border-slate-200 p-5 shadow-xs transition-all ${
        onClick ? 'cursor-pointer hover:border-slate-300 hover:shadow-sm' : ''
      }`}
    >
      <div className="flex items-start justify-between">
        <div>
          <span className="text-xs font-medium uppercase tracking-wider text-slate-500">
            {title}
          </span>
          <div className="mt-2 text-2xl font-bold tracking-tight text-slate-900">
            {value}
          </div>
          {subtitle && (
            <p className="mt-1 text-xs text-slate-500">{subtitle}</p>
          )}
        </div>
        <div className="rounded-lg bg-slate-50 p-2.5 text-slate-700 border border-slate-100">
          <Icon className="h-5 w-5" />
        </div>
      </div>
      {badge && (
        <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
          <span className={`inline-block px-2 py-0.5 text-xs font-medium rounded ${getBadgeClass()}`}>
            {badge}
          </span>
        </div>
      )}
    </div>
  );
};
