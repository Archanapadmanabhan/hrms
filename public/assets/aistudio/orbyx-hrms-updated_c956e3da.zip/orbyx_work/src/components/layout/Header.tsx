import React, { useState, useEffect } from 'react';
import { PersonaSwitcher } from './PersonaSwitcher';
import { NotificationDropdown } from './NotificationDropdown';
import { useAuth } from '../../services/authContext';
import { hrmsService } from '../../services/hrmsService';
import { db, subscribeToDB } from '../../db/storage';
import { LogIn, LogOut, CheckCircle2 } from 'lucide-react';
import { NavTab } from './Sidebar';

interface HeaderProps {
  currentTab: NavTab;
}

export const Header: React.FC<HeaderProps> = ({ currentTab }) => {
  const { currentUser, currentEmployee } = useAuth();
  const [todayRecord, setTodayRecord] = useState(() => {
    const today = new Date().toISOString().split('T')[0];
    return db.getAttendanceRecords().find(
      (r) => r.employeeId === currentUser.employeeId && r.date === today
    );
  });

  useEffect(() => {
    const update = () => {
      const today = new Date().toISOString().split('T')[0];
      setTodayRecord(
        db.getAttendanceRecords().find(
          (r) => r.employeeId === currentUser.employeeId && r.date === today
        )
      );
    };
    const unsubscribe = subscribeToDB(update);
    update();
    return unsubscribe;
  }, [currentUser]);

  const titles: Record<NavTab, { title: string; subtitle: string }> = {
    dashboard: { title: 'Executive Overview', subtitle: 'Workforce operational metrics and daily status' },
    organization: { title: 'Organization Setup', subtitle: 'Legal entity, branches, departments, designations & reporting structure' },
    employees: { title: 'Employee Setup', subtitle: 'Employee directory, profiles, onboarding, documents & offboarding' },
    clients: { title: 'Client Management', subtitle: 'Client organizations, employee deployments, assignment lifecycle & utilization' },
    leave: { title: 'Leave & Absence Management', subtitle: 'Leave applications, approvals, balance ledgers & calendar' },
    attendance: { title: 'Shifts & Attendance', subtitle: 'Punches, shift schedules, overtime & correction workflows' },
    expenses: { title: 'Expense Management', subtitle: 'Employee reimbursement claims, receipt review & payouts' },
    payroll: { title: 'Payroll & Compensation', subtitle: 'Salary structures, monthly processing, payslips & tax statutory' },
    assets: { title: 'Asset Management', subtitle: 'Hardware, email accounts, software licenses, subscriptions & access lifecycle' },
    reports: { title: 'Operational Analytics & Reports', subtitle: 'Aggregated cross-module exports and statutory summaries' },
    settings: { title: 'Organization Settings', subtitle: 'Company legal profile, branches, departments & system audit log' }
  };

  const currentMeta = titles[currentTab] || { title: 'Dashboard', subtitle: 'HRMS' };

  const handleQuickPunch = (type: 'check-in' | 'check-out') => {
    hrmsService.punchAttendance(currentUser.employeeId, type, currentUser.id, currentUser.name);
  };

  return (
    <header className="h-16 bg-white border-b border-slate-200 px-6 flex items-center justify-between shrink-0">
      <div>
        <div className="flex items-center gap-2">
          <h1 className="text-base font-bold text-slate-900 tracking-tight">{currentMeta.title}</h1>
        </div>
        <p className="text-[11px] text-slate-500 hidden sm:block">{currentMeta.subtitle}</p>
      </div>

      <div className="flex items-center gap-3">
        {/* Quick Punch Bar for Employee */}
        <div className="hidden md:flex items-center gap-2 pr-3 border-r border-slate-200">
          {!todayRecord?.checkInTime ? (
            <button
              onClick={() => handleQuickPunch('check-in')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium shadow-2xs transition-colors"
            >
              <LogIn className="h-3.5 w-3.5" />
              <span>Web Check-In</span>
            </button>
          ) : !todayRecord?.checkOutTime ? (
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-600 flex items-center gap-1">
                <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                <span>In at {todayRecord.checkInTime}</span>
              </span>
              <button
                onClick={() => handleQuickPunch('check-out')}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-900 text-white text-xs font-medium transition-colors"
              >
                <LogOut className="h-3 w-3" />
                <span>Check Out</span>
              </button>
            </div>
          ) : (
            <span className="text-xs text-slate-500 flex items-center gap-1 font-mono">
              <CheckCircle2 className="h-3.5 w-3.5 text-slate-400" />
              <span>Shift Completed ({todayRecord.totalHoursWorked}h)</span>
            </span>
          )}
        </div>

        {/* Notifications Dropdown */}
        <NotificationDropdown />

        {/* Persona Switcher Dropdown */}
        <PersonaSwitcher />
      </div>
    </header>
  );
};
