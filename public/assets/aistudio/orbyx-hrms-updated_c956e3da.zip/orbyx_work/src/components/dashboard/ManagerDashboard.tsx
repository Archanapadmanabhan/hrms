import React, { useState } from 'react';
import {
  Users,
  CalendarCheck,
  Receipt,
  Clock,
  Check,
  X,
  AlertCircle,
  Laptop
} from 'lucide-react';
import { StatCard } from '../common/StatCard';
import { useAuth } from '../../services/authContext';
import { db } from '../../db/storage';
import { hrmsService } from '../../services/hrmsService';
import { NavTab } from '../layout/Sidebar';

interface ManagerDashboardProps {
  onNavigate: (tab: NavTab) => void;
}

export const ManagerDashboard: React.FC<ManagerDashboardProps> = ({ onNavigate }) => {
  const { currentUser } = useAuth();
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  // My direct reports (active only)
  const teamMembers = db.getEmployees().filter(
    (e) => e.reportingManagerId === currentUser.employeeId && e.status !== 'Inactive' && e.status !== 'Separated'
  );
  const teamIds = teamMembers.map((e) => e.id);

  // Pending Leave requests routed to this manager/senior manager
  const pendingLeaves = db
    .getLeaveApplications()
    .filter((a) => a.approverId === currentUser.employeeId && a.status === 'Pending Approval');

  // Pending Expense claims routed to this manager/senior manager
  const pendingExpenses = db
    .getExpenseClaims()
    .filter((c) => c.approverId === currentUser.employeeId && c.status === 'Pending Manager Approval');

  // Pending Attendance corrections routed to this manager/senior manager
  const pendingCorrections = db
    .getCorrectionRequests()
    .filter((r) => r.approverId === currentUser.employeeId && r.status === 'Pending');

  // Team members on leave today
  const todayStr = new Date().toISOString().split('T')[0];
  const teamOnLeave = db.getLeaveApplications().filter(
    (a) => teamIds.includes(a.employeeId) && a.status === 'Approved' && a.startDate <= todayStr && a.endDate >= todayStr
  );

  // Team assets
  const teamAssets = db.getAssets().filter(
    (a) => a.currentEmployeeId && teamIds.includes(a.currentEmployeeId)
  );

  const handleApproveLeave = (id: string) => {
    hrmsService.decideLeave(id, 'Approved', 'Approved by Team Manager', currentUser.id, currentUser.name);
    setActionMessage('Leave application approved.');
    setTimeout(() => setActionMessage(null), 3000);
  };

  const handleRejectLeave = (id: string) => {
    hrmsService.decideLeave(id, 'Rejected', 'Rejected by Manager due to sprint coverage', currentUser.id, currentUser.name);
    setActionMessage('Leave application rejected.');
    setTimeout(() => setActionMessage(null), 3000);
  };

  const handleApproveExpense = (id: string) => {
    hrmsService.decideExpenseClaim(id, 'Approved', 'Approved by Team Manager', currentUser.id, currentUser.name);
    setActionMessage('Expense claim approved and forwarded to finance.');
    setTimeout(() => setActionMessage(null), 3000);
  };

  const handleRejectExpense = (id: string) => {
    hrmsService.decideExpenseClaim(id, 'Rejected', 'Receipt or business purpose needs revision', currentUser.id, currentUser.name);
    setActionMessage('Expense claim rejected.');
    setTimeout(() => setActionMessage(null), 3000);
  };

  return (
    <div className="space-y-6">
      {actionMessage && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-xs font-medium flex items-center gap-2">
          <Check className="h-4 w-4" />
          <span>{actionMessage}</span>
        </div>
      )}

      {/* Team Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Direct Reports"
          value={teamMembers.length}
          subtitle="Engineering & Design team members"
          icon={Users}
          badge="Reporting to You"
          badgeColor="indigo"
          onClick={() => onNavigate('employees')}
        />
        <StatCard
          title="Team on Leave Today"
          value={teamOnLeave.length}
          subtitle={teamOnLeave.length > 0 ? 'Review project bandwith' : 'Full team available'}
          icon={CalendarCheck}
          badge={teamOnLeave.length > 0 ? 'Active Absence' : 'Optimal'}
          badgeColor={teamOnLeave.length > 0 ? 'amber' : 'emerald'}
          onClick={() => onNavigate('leave')}
        />
        <StatCard
          title="Pending Approvals"
          value={pendingLeaves.length + pendingExpenses.length + pendingCorrections.length}
          subtitle={`${pendingLeaves.length} leaves · ${pendingExpenses.length} claims · ${pendingCorrections.length} punches`}
          icon={AlertCircle}
          badge={pendingLeaves.length + pendingExpenses.length > 0 ? 'Action Required' : 'Up to Date'}
          badgeColor={pendingLeaves.length + pendingExpenses.length > 0 ? 'rose' : 'emerald'}
        />
        <StatCard
          title="Team Assets"
          value={teamAssets.length}
          subtitle="Laptops and workstations deployed"
          icon={Laptop}
          badge="Allocated"
          badgeColor="slate"
          onClick={() => onNavigate('assets')}
        />
      </div>

      {/* Approval Queues */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pending Leave Applications */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <span className="text-xs font-semibold text-slate-900 uppercase tracking-wider flex items-center gap-2">
              <CalendarCheck className="h-4 w-4 text-indigo-600" />
              Pending Team Leave Requests
            </span>
            <span className="text-xs text-slate-500">{pendingLeaves.length} waiting</span>
          </div>

          <div className="mt-4 space-y-3">
            {pendingLeaves.length === 0 ? (
              <div className="py-8 text-center text-xs text-slate-400">
                No pending leave requests from your reporting hierarchy.
              </div>
            ) : (
              pendingLeaves.map((app) => {
                const emp = teamMembers.find((e) => e.id === app.employeeId);
                const lt = db.getLeaveTypes().find((l) => l.id === app.leaveTypeId);
                return (
                  <div key={app.id} className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs">
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="font-semibold text-slate-900">
                          {emp ? `${emp.firstName} ${emp.lastName}` : app.employeeId}
                        </p>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          {lt?.name} · {app.totalDays} day(s) ({app.startDate} to {app.endDate})
                        </p>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleApproveLeave(app.id)}
                          className="p-1.5 rounded-md bg-emerald-600 text-white hover:bg-emerald-700 transition-colors"
                          title="Approve"
                        >
                          <Check className="h-3.5 w-3.5" />
                        </button>
                        <button
                          onClick={() => handleRejectLeave(app.id)}
                          className="p-1.5 rounded-md bg-rose-600 text-white hover:bg-rose-700 transition-colors"
                          title="Reject"
                        >
                          <X className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                    <p className="text-slate-600 mt-2 text-[11px] bg-white p-2 rounded border border-slate-100">
                      Reason: "{app.reason}"
                    </p>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Pending Expense Claims */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <span className="text-xs font-semibold text-slate-900 uppercase tracking-wider flex items-center gap-2">
              <Receipt className="h-4 w-4 text-emerald-600" />
              Pending Team Expense Claims
            </span>
            <span className="text-xs text-slate-500">{pendingExpenses.length} waiting</span>
          </div>

          <div className="mt-4 space-y-3">
            {pendingExpenses.length === 0 ? (
              <div className="py-8 text-center text-xs text-slate-400">
                No pending expense claims from your reporting team.
              </div>
            ) : (
              pendingExpenses.map((claim) => {
                const emp = teamMembers.find((e) => e.id === claim.employeeId);
                const cat = db.getExpenseCategories().find((c) => c.id === claim.categoryId);
                return (
                  <div key={claim.id} className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="font-semibold text-slate-900">
                            {emp ? `${emp.firstName} ${emp.lastName}` : claim.employeeId}
                          </p>
                          <span className="font-mono text-indigo-600 font-bold">
                            ₹{claim.amount.toLocaleString()}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          {cat?.name} · Claim {claim.claimNumber} · Date: {claim.expenseDate}
                        </p>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleApproveExpense(claim.id)}
                          className="p-1.5 rounded-md bg-emerald-600 text-white hover:bg-emerald-700 transition-colors"
                          title="Approve"
                        >
                          <Check className="h-3.5 w-3.5" />
                        </button>
                        <button
                          onClick={() => handleRejectExpense(claim.id)}
                          className="p-1.5 rounded-md bg-rose-600 text-white hover:bg-rose-700 transition-colors"
                          title="Reject"
                        >
                          <X className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                    <p className="text-slate-600 mt-2 text-[11px] bg-white p-2 rounded border border-slate-100">
                      Title: {claim.title} | Purpose: "{claim.businessPurpose}"
                    </p>
                    {claim.receiptFileName && (
                      <p className="mt-1 text-[10px] text-indigo-600">Attachment: {claim.receiptFileName}</p>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
