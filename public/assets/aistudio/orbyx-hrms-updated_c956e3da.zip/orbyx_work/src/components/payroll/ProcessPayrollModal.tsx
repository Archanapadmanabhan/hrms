import React, { useState, useEffect } from 'react';
import { Modal } from '../common/Modal';
import { db } from '../../db/storage';
import { hrmsService } from '../../services/hrmsService';
import { useAuth } from '../../services/authContext';
import { PayrollRun, PayrollLineItem } from '../../types/hrms';
import { Calculator, CheckCircle2, AlertTriangle, ArrowRight, Lock } from 'lucide-react';

interface ProcessPayrollModalProps {
  isOpen: boolean;
  onClose: () => void;
  onFinalized: () => void;
}

export const ProcessPayrollModal: React.FC<ProcessPayrollModalProps> = ({
  isOpen,
  onClose,
  onFinalized
}) => {
  const { currentUser } = useAuth();
  const [month, setMonth] = useState(10); // October
  const [year, setYear] = useState(2026);
  const [preview, setPreview] = useState<{ run: PayrollRun; items: PayrollLineItem[] } | null>(null);
  const [step, setStep] = useState<1 | 2>(1);
  const [isFinalizing, setIsFinalizing] = useState(false);

  useEffect(() => {
    if (isOpen) {
      const p = hrmsService.generatePayrollPreview(month, year, currentUser.id, currentUser.name);
      setPreview(p);
      setStep(1);
    }
  }, [isOpen, month, year]);

  const handleRecalculate = () => {
    const p = hrmsService.generatePayrollPreview(month, year, currentUser.id, currentUser.name);
    setPreview(p);
  };

  const handleFinalize = () => {
    if (!preview) return;
    setIsFinalizing(true);
    hrmsService.finalizePayrollRun(preview.run, preview.items, currentUser.id, currentUser.name);
    setIsFinalizing(false);
    onFinalized();
    onClose();
  };

  if (!preview) return null;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Monthly Payroll Processing Engine"
      description={`Period: ${preview.run.periodLabel} · Controlled salary execution`}
      maxWidth="3xl"
    >
      <div className="space-y-4 text-xs">
        {/* Step Indicator */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-200">
          <div className="flex items-center gap-4">
            <span className={`font-semibold flex items-center gap-1.5 ${step === 1 ? 'text-indigo-600' : 'text-slate-500'}`}>
              <span className="h-5 w-5 rounded-full bg-indigo-50 border border-indigo-200 flex items-center justify-center text-[10px]">1</span>
              Attendance & Calculation
            </span>
            <span className="text-slate-300">&rarr;</span>
            <span className={`font-semibold flex items-center gap-1.5 ${step === 2 ? 'text-indigo-600' : 'text-slate-400'}`}>
              <span className="h-5 w-5 rounded-full bg-slate-100 flex items-center justify-center text-[10px]">2</span>
              Review Exceptions & Lock
            </span>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={month}
              onChange={(e) => setMonth(Number(e.target.value))}
              className="px-2.5 py-1 bg-slate-50 border border-slate-200 rounded text-xs text-slate-700 font-medium"
            >
              <option value={9}>September 2026</option>
              <option value={10}>October 2026</option>
              <option value={11}>November 2026</option>
            </select>
          </div>
        </div>

        {/* STEP 1: Summary Cards */}
        {step === 1 && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-slate-400 block text-[10px] uppercase">Active Employees</span>
                <span className="text-lg font-bold text-slate-900">{preview.run.totalEmployees}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-slate-400 block text-[10px] uppercase">Gross Earnings</span>
                <span className="text-lg font-bold text-slate-900 font-mono">₹{preview.run.totalGrossPay.toLocaleString()}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-slate-400 block text-[10px] uppercase">Total Deductions</span>
                <span className="text-lg font-bold text-rose-600 font-mono">₹{preview.run.totalDeductions.toLocaleString()}</span>
              </div>
              <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200">
                <span className="text-emerald-700 block text-[10px] uppercase font-semibold">Net Pay Due</span>
                <span className="text-lg font-bold text-emerald-900 font-mono">₹{preview.run.totalNetPay.toLocaleString()}</span>
              </div>
            </div>

            {/* Attendance & LOP alerts */}
            <div className="p-3 bg-amber-50/70 rounded-lg border border-amber-200 flex items-start gap-2 text-amber-900">
              <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5 text-amber-600" />
              <div>
                <p className="font-semibold text-xs">Attendance & Loss-of-Pay (LOP) Synced</p>
                <p className="text-[11px] text-amber-800 mt-0.5">
                  Unpaid leaves and unapproved absences are automatically prorated from daily gross pay.
                  Statutory PF is computed at 12% of basic; Professional tax slab ₹200 applied.
                </p>
              </div>
            </div>

            {/* Line items table preview */}
            <div className="border border-slate-200 rounded-lg overflow-hidden max-h-60 overflow-y-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 text-slate-600 font-semibold border-b border-slate-200 sticky top-0">
                  <tr>
                    <th className="px-3 py-2">Employee</th>
                    <th className="px-3 py-2">Payable Days</th>
                    <th className="px-3 py-2 text-right">Gross</th>
                    <th className="px-3 py-2 text-right">Deductions</th>
                    <th className="px-3 py-2 text-right">Net Payable</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {preview.items.map((item) => (
                    <tr key={item.id} className="hover:bg-slate-50">
                      <td className="px-3 py-2 font-medium text-slate-900">
                        {item.employeeName}
                        <span className="block text-[10px] text-slate-400 font-mono">{item.employeeId} · {item.departmentName}</span>
                      </td>
                      <td className="px-3 py-2 font-mono text-slate-700">
                        {item.payableDays} / {item.workingDaysInMonth}
                        {item.unpaidLeaves > 0 && (
                          <span className="block text-[10px] text-rose-600 font-semibold">({item.unpaidLeaves}d LOP)</span>
                        )}
                      </td>
                      <td className="px-3 py-2 text-right font-mono text-slate-800">₹{item.grossEarnings.toLocaleString()}</td>
                      <td className="px-3 py-2 text-right font-mono text-rose-600">-₹{item.totalDeductions.toLocaleString()}</td>
                      <td className="px-3 py-2 text-right font-mono font-bold text-slate-900">₹{item.netPayable.toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex justify-between items-center pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={handleRecalculate}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 rounded text-slate-700 font-medium"
              >
                Recalculate Inputs
              </button>
              <button
                type="button"
                onClick={() => setStep(2)}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-semibold"
              >
                <span>Proceed to Final Review</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: Final Review & Lock */}
        {step === 2 && (
          <div className="space-y-4">
            <div className="p-4 bg-slate-900 text-white rounded-xl space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <span className="text-xs uppercase tracking-wider text-slate-400">Payroll Authorization Ledger</span>
                <span className="text-xs font-mono font-bold text-indigo-400">{preview.run.periodLabel}</span>
              </div>
              <div className="grid grid-cols-3 gap-4 text-xs">
                <div>
                  <span className="text-slate-400 block text-[11px]">Total Net Bank Outflow</span>
                  <p className="text-xl font-bold font-mono mt-0.5 text-white">₹{preview.run.totalNetPay.toLocaleString()}</p>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Employer PF & ESI</span>
                  <p className="text-xl font-bold font-mono mt-0.5 text-indigo-300">
                    ₹{preview.items.reduce((acc, i) => acc + i.pfEmployer + i.esiEmployer, 0).toLocaleString()}
                  </p>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Total Company CTC Cost</span>
                  <p className="text-xl font-bold font-mono mt-0.5 text-emerald-400">
                    ₹{preview.items.reduce((acc, i) => acc + i.totalEmployerCost, 0).toLocaleString()}
                  </p>
                </div>
              </div>
            </div>

            <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-700 space-y-2">
              <p className="font-semibold text-slate-900">Locking Invariants & Security Enforcement</p>
              <ul className="list-disc pl-4 space-y-1 text-[11px] text-slate-600">
                <li>Once finalized, this payroll period will be permanently locked against silent modifications.</li>
                <li>Individual payslips will be generated for all {preview.run.totalEmployees} employees immediately.</li>
                <li>In-app notifications will be delivered to employee portals.</li>
                <li>An immutable audit log will be written recording timestamp and approver credentials.</li>
              </ul>
            </div>

            <div className="flex justify-between items-center pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 rounded text-slate-700 font-medium"
              >
                &larr; Back to Breakdown
              </button>
              <button
                type="button"
                onClick={handleFinalize}
                disabled={isFinalizing}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-semibold shadow-2xs"
              >
                <Lock className="h-4 w-4" />
                <span>Finalize & Lock Payroll ({preview.run.periodLabel})</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
};
