import React from 'react';
import { Modal } from '../common/Modal';
import { PayrollLineItem } from '../../types/hrms';
import { db } from '../../db/storage';
import { Printer, Building, FileCheck } from 'lucide-react';

interface PayslipModalProps {
  item: PayrollLineItem | null;
  periodLabel?: string;
  isOpen: boolean;
  onClose: () => void;
}

export const PayslipModal: React.FC<PayslipModalProps> = ({
  item,
  periodLabel = 'September 2026',
  isOpen,
  onClose
}) => {
  if (!item) return null;

  const company = db.getCompanyProfile();
  const emp = db.getEmployeeById(item.employeeId);

  const handlePrint = () => {
    window.print();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Salary Payslip"
      description={`Official payslip for period: ${periodLabel}`}
      maxWidth="2xl"
    >
      <div className="space-y-6 text-xs" id="printable-payslip">
        {/* Company Header */}
        <div className="flex items-start justify-between border-b-2 border-slate-900 pb-4">
          <div>
            <h2 className="text-base font-bold text-slate-900 tracking-tight">{company.legalEntity}</h2>
            <p className="text-slate-500 text-[11px] mt-0.5">{company.address}, {company.city}, {company.state} - {company.zipCode}</p>
            <p className="text-slate-500 text-[11px]">PAN/Tax: {company.taxId} · PF Reg: {company.pfRegistrationNumber}</p>
          </div>
          <div className="text-right">
            <span className="text-xs font-mono font-bold uppercase tracking-wider text-indigo-700 bg-indigo-50 border border-indigo-200 px-2.5 py-1 rounded">
              Payslip · {periodLabel}
            </span>
          </div>
        </div>

        {/* Employee Summary Details */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-xl bg-slate-50 border border-slate-200">
          <div>
            <span className="text-slate-400 block text-[10px] uppercase">Employee Name</span>
            <span className="font-bold text-slate-900">{item.employeeName}</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px] uppercase">Employee ID</span>
            <span className="font-mono font-bold text-slate-800">{item.employeeId}</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px] uppercase">Department</span>
            <span className="font-semibold text-slate-800">{item.departmentName}</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px] uppercase">Designation</span>
            <span className="font-semibold text-slate-800">{item.designationTitle}</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px] uppercase">Bank Account</span>
            <span className="font-mono text-slate-700">{item.bankAccountNumber}</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px] uppercase">PAN Number</span>
            <span className="font-mono text-slate-700">{item.panNumber}</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px] uppercase">Payable / Total Days</span>
            <span className="font-mono font-semibold text-slate-800">{item.payableDays} / {item.workingDaysInMonth} days</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px] uppercase">Loss of Pay (Unpaid)</span>
            <span className="font-mono font-semibold text-rose-600">{item.unpaidLeaves} days</span>
          </div>
        </div>

        {/* Earnings & Deductions Tables */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Earnings */}
          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <div className="bg-slate-100 px-3 py-2 font-bold text-slate-800 border-b border-slate-200 flex justify-between">
              <span>Earnings</span>
              <span>Amount (₹)</span>
            </div>
            <div className="p-3 space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-600">Basic Salary</span>
                <span className="font-mono font-medium text-slate-900">₹{item.basicEarnings.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">House Rent Allowance (HRA)</span>
                <span className="font-mono font-medium text-slate-900">₹{item.hraEarnings.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Special Allowance</span>
                <span className="font-mono font-medium text-slate-900">₹{item.specialAllowanceEarnings.toLocaleString()}</span>
              </div>
              <div className="pt-2 border-t border-slate-100 flex justify-between font-bold text-slate-900">
                <span>Total Gross Earnings</span>
                <span className="font-mono">₹{item.grossEarnings.toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Deductions */}
          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <div className="bg-slate-100 px-3 py-2 font-bold text-slate-800 border-b border-slate-200 flex justify-between">
              <span>Deductions & Statutory</span>
              <span>Amount (₹)</span>
            </div>
            <div className="p-3 space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-600">Provident Fund (Employee 12%)</span>
                <span className="font-mono font-medium text-slate-900">₹{item.pfEmployee.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Professional Tax (PT)</span>
                <span className="font-mono font-medium text-slate-900">₹{item.professionalTax.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Tax Deducted at Source (TDS)</span>
                <span className="font-mono font-medium text-slate-900">₹{item.tdsWithholding.toLocaleString()}</span>
              </div>
              {item.unpaidLeaveDeduction > 0 && (
                <div className="flex justify-between text-rose-600">
                  <span>Loss of Pay (LOP Adjustment)</span>
                  <span className="font-mono font-medium">₹{item.unpaidLeaveDeduction.toLocaleString()}</span>
                </div>
              )}
              <div className="pt-2 border-t border-slate-100 flex justify-between font-bold text-rose-700">
                <span>Total Deductions</span>
                <span className="font-mono">₹{item.totalDeductions.toLocaleString()}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Net Pay Banner */}
        <div className="p-4 rounded-xl bg-indigo-900 text-white flex items-center justify-between">
          <div>
            <span className="text-[11px] uppercase tracking-wider text-indigo-300">Net Take-Home Salary</span>
            <p className="text-2xl font-bold font-mono mt-0.5">₹{item.netPayable.toLocaleString()}</p>
          </div>
          <div className="text-right text-xs text-indigo-200">
            <span className="inline-flex items-center gap-1 font-semibold text-emerald-300">
              <FileCheck className="h-4 w-4" />
              Direct Deposit Verified
            </span>
            <p className="text-[10px] text-indigo-300 mt-1">This is a system generated payslip.</p>
          </div>
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
          >
            Close
          </button>
          <button
            type="button"
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors"
          >
            <Printer className="h-3.5 w-3.5" />
            <span>Print Payslip</span>
          </button>
        </div>
      </div>
    </Modal>
  );
};
