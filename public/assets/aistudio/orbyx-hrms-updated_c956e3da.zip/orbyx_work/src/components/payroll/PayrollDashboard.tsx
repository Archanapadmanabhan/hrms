import React, { useState } from 'react';
import { db } from '../../db/storage';
import { useAuth } from '../../services/authContext';
import { hrmsService } from '../../services/hrmsService';
import { PayrollRun, PayrollLineItem } from '../../types/hrms';
import { DataTable, Column } from '../common/DataTable';
import { ExportButton } from '../common/ExportButton';
import { StatCard } from '../common/StatCard';
import { PayslipModal } from './PayslipModal';
import { ProcessPayrollModal } from './ProcessPayrollModal';
import {
  CreditCard,
  CheckCircle2,
  Lock,
  Plus,
  Eye,
  Send,
  Building,
  Layers,
  ShieldCheck
} from 'lucide-react';

export const PayrollDashboard: React.FC = () => {
  const { currentUser, canProcessPayroll } = useAuth();
  const isHR = currentUser.role === 'hr_admin';
  const [activeTab, setActiveTab] = useState<'runs' | 'payslips' | 'structures'>(isHR ? 'runs' : 'payslips');
  const [isProcessModalOpen, setIsProcessModalOpen] = useState(false);
  const [selectedPayslipItem, setSelectedPayslipItem] = useState<PayrollLineItem | null>(null);

  // Disburse modal
  const [disburseRunId, setDisburseRunId] = useState<string | null>(null);
  const [disburseRef, setDisburseRef] = useState('');

  const payrollRuns = db.getPayrollRuns();
  const lineItems = db.getPayrollLineItems();
  const structures = db.getSalaryStructures();
  const currentEmp = db.getEmployeeById(currentUser.employeeId);
  const myStructure = currentEmp ? structures.find((s) => s.id === currentEmp.salaryStructureId) : null;

  // Scoped line items:
  // If HR, show all; If employee/manager, show strictly own items!
  const visibleLineItems = isHR
    ? lineItems
    : lineItems.filter((item) => item.employeeId === currentUser.employeeId);

  const myLatestPayslip = visibleLineItems[visibleLineItems.length - 1];
  const latestRun = payrollRuns[0];

  const handleDisburseConfirm = () => {
    if (!disburseRunId || !disburseRef) return;
    hrmsService.recordPayrollDisbursement(
      disburseRunId,
      disburseRef,
      currentUser.id,
      currentUser.name
    );
    setDisburseRunId(null);
    setDisburseRef('');
  };

  // Run columns
  const runColumns: Column<PayrollRun>[] = [
    {
      header: 'Payroll Period',
      accessorKey: 'periodLabel',
      sortable: true,
      cell: (run) => (
        <div>
          <span className="font-bold text-slate-900">{run.periodLabel}</span>
          <span className="text-[11px] text-slate-500 block font-mono">
            {run.startDate} to {run.endDate}
          </span>
        </div>
      )
    },
    {
      header: 'Headcount',
      accessorKey: 'totalEmployees',
      sortable: true,
      cell: (run) => (
        <span className="font-semibold text-slate-800">{run.totalEmployees} employees</span>
      )
    },
    {
      header: 'Total Gross',
      accessorKey: 'totalGrossPay',
      sortable: true,
      cell: (run) => (
        <span className="font-mono text-slate-800">₹{run.totalGrossPay.toLocaleString()}</span>
      )
    },
    {
      header: 'Total Deductions',
      accessorKey: 'totalDeductions',
      sortable: true,
      cell: (run) => (
        <span className="font-mono text-rose-600">-₹{run.totalDeductions.toLocaleString()}</span>
      )
    },
    {
      header: 'Net Outflow',
      accessorKey: 'totalNetPay',
      sortable: true,
      cell: (run) => (
        <span className="font-mono font-bold text-slate-900">₹{run.totalNetPay.toLocaleString()}</span>
      )
    },
    {
      header: 'Status',
      accessorKey: 'status',
      sortable: true,
      cell: (run) => (
        <span
          className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-xs font-medium ${
            run.status === 'Paid'
              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
              : run.status === 'Finalized'
              ? 'bg-blue-50 text-blue-700 border border-blue-200'
              : 'bg-amber-50 text-amber-700 border border-amber-200'
          }`}
        >
          {run.status === 'Paid' ? <CheckCircle2 className="h-3 w-3" /> : <Lock className="h-3 w-3" />}
          <span>{run.status}</span>
        </span>
      )
    },
    {
      header: 'Actions',
      cell: (run) => (
        <div className="flex items-center gap-1.5">
          {isHR && run.status === 'Finalized' && (
            <button
              onClick={() => {
                setDisburseRunId(run.id);
                setDisburseRef(`UTR-${Date.now().toString().slice(-8)}`);
              }}
              className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors"
            >
              <Send className="h-3 w-3" />
              <span>Record Payment</span>
            </button>
          )}
          <button
            onClick={() => setActiveTab('payslips')}
            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
          >
            <Eye className="h-3 w-3" />
            <span>Payslips</span>
          </button>
        </div>
      )
    }
  ];

  // Payslip columns
  const payslipColumns: Column<PayrollLineItem>[] = [
    {
      header: 'Employee',
      accessorKey: 'employeeName',
      sortable: true,
      cell: (item) => (
        <div>
          <span className="font-semibold text-slate-900">{item.employeeName}</span>
          <span className="text-[11px] text-slate-500 block font-mono">
            {item.employeeId} · {item.departmentName}
          </span>
        </div>
      )
    },
    {
      header: 'Payable Days',
      accessorKey: 'payableDays',
      sortable: true,
      cell: (item) => (
        <span className="font-mono text-slate-700">
          {item.payableDays} / {item.workingDaysInMonth}
          {item.unpaidLeaves > 0 && <span className="text-rose-600 block text-[10px]">({item.unpaidLeaves}d LOP)</span>}
        </span>
      )
    },
    {
      header: 'Gross Earnings',
      accessorKey: 'grossEarnings',
      sortable: true,
      cell: (item) => <span className="font-mono text-slate-800">₹{item.grossEarnings.toLocaleString()}</span>
    },
    {
      header: 'Deductions (PF/PT/TDS)',
      accessorKey: 'totalDeductions',
      sortable: true,
      cell: (item) => <span className="font-mono text-rose-600">-₹{item.totalDeductions.toLocaleString()}</span>
    },
    {
      header: 'Net Pay',
      accessorKey: 'netPayable',
      sortable: true,
      cell: (item) => (
        <span className="font-mono font-bold text-slate-900">₹{item.netPayable.toLocaleString()}</span>
      )
    },
    {
      header: 'Status',
      accessorKey: 'status',
      sortable: true,
      cell: (item) => (
        <span className="px-2 py-0.5 rounded text-xs font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
          {item.status}
        </span>
      )
    },
    {
      header: 'Payslip',
      cell: (item) => (
        <button
          onClick={() => setSelectedPayslipItem(item)}
          className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-colors"
        >
          <Eye className="h-3 w-3" />
          <span>View Slip</span>
        </button>
      )
    }
  ];

  const exportData = visibleLineItems.map((i) => ({
    EmployeeID: i.employeeId,
    Name: i.employeeName,
    Department: i.departmentName,
    PayableDays: i.payableDays,
    Gross: i.grossEarnings,
    Basic: i.basicEarnings,
    HRA: i.hraEarnings,
    PFEmployee: i.pfEmployee,
    PT: i.professionalTax,
    TDS: i.tdsWithholding,
    TotalDeductions: i.totalDeductions,
    NetPay: i.netPayable,
    BankAccount: i.bankAccountNumber
  }));

  return (
    <div className="space-y-6">
      {/* Stat Cards */}
      {isHR ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Payroll Periods"
            value={payrollRuns.length}
            subtitle={`Latest: ${latestRun?.periodLabel || 'None'}`}
            icon={CreditCard}
            badge="Audit Locked"
            badgeColor="slate"
          />
          <StatCard
            title="Latest Net Outflow"
            value={`₹${(latestRun?.totalNetPay || 0).toLocaleString()}`}
            subtitle={`${latestRun?.totalEmployees || 0} employees disbursed`}
            icon={CheckCircle2}
            badge={latestRun?.status || 'Finalized'}
            badgeColor="emerald"
          />
          <StatCard
            title="Statutory PF / ESI"
            value="100% Compliant"
            subtitle="Formulas & slabs auto-calculated"
            icon={ShieldCheck}
            badge="India Payroll Rules"
            badgeColor="indigo"
          />
          <StatCard
            title="Active Structures"
            value={structures.length}
            subtitle="Grade-wise salary matrices"
            icon={Layers}
            badge="Configurable"
            badgeColor="blue"
            onClick={() => setActiveTab('structures')}
          />
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="My Gross Monthly"
            value={`₹${(myStructure?.grossMonthly || (currentEmp?.baseSalaryAnnual ? Math.round(currentEmp.baseSalaryAnnual / 12) : 0)).toLocaleString()}`}
            subtitle={`Annual CTC: ₹${((currentEmp?.baseSalaryAnnual || myStructure?.ctcAnnual || 0)).toLocaleString()}`}
            icon={CreditCard}
            badge="Assigned Structure"
            badgeColor="indigo"
          />
          <StatCard
            title="Latest Net Pay"
            value={myLatestPayslip ? `₹${myLatestPayslip.netPayable.toLocaleString()}` : '₹0'}
            subtitle={myLatestPayslip?.periodLabel || 'Latest disbursed payslip'}
            icon={CheckCircle2}
            badge="Finalized"
            badgeColor="emerald"
          />
          <StatCard
            title="Total Deductions"
            value={myLatestPayslip ? `₹${myLatestPayslip.totalDeductions.toLocaleString()}` : '₹0'}
            subtitle="PF, PT & TDS withholding"
            icon={ShieldCheck}
            badge="Statutory"
            badgeColor="slate"
          />
          <StatCard
            title="My Structure"
            value={myStructure?.name || 'Assigned Structure'}
            subtitle="View salary component breakdown"
            icon={Layers}
            badge="Active"
            badgeColor="blue"
            onClick={() => setActiveTab('structures')}
          />
        </div>
      )}

      {/* Tabs and Action Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white p-3.5 rounded-xl border border-slate-200">
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
          {isHR && (
            <button
              onClick={() => setActiveTab('runs')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                activeTab === 'runs' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Payroll Runs ({payrollRuns.length})
            </button>
          )}
          <button
            onClick={() => setActiveTab('payslips')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'payslips' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {isHR ? `All Employee Payslips (${lineItems.length})` : `My Payslips (${visibleLineItems.length})`}
          </button>
          <button
            onClick={() => setActiveTab('structures')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'structures' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {isHR ? `Salary Structures (${structures.length})` : 'My Salary Structure'}
          </button>
        </div>

        <div className="flex items-center gap-2">
          <ExportButton data={exportData} fileName={isHR ? 'Orbyx_Payroll_Register' : `Orbyx_My_Payslips_${currentUser.employeeId}`} />
          {canProcessPayroll() && (
            <button
              onClick={() => setIsProcessModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg shadow-2xs transition-colors"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>Process New Payroll</span>
            </button>
          )}
        </div>
      </div>

      {/* Content: Runs */}
      {isHR && activeTab === 'runs' && (
        <DataTable
          data={payrollRuns}
          columns={runColumns}
          searchPlaceholder="Search payroll periods..."
        />
      )}

      {/* Content: Payslips */}
      {activeTab === 'payslips' && (
        <DataTable
          data={visibleLineItems}
          columns={payslipColumns}
          searchPlaceholder="Search payslips..."
        />
      )}

      {/* Content: Salary Structures */}
      {activeTab === 'structures' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {(isHR ? structures : (myStructure ? [myStructure] : [])).map((s) => (
            <div key={s.id} className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-3">
              <div className="pb-3 border-b border-slate-100 flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">{s.name}</h4>
                  <p className="text-[11px] text-slate-500">{s.description}</p>
                </div>
              </div>
              <div className="flex justify-between items-baseline pt-1">
                <span className="text-xs text-slate-500">Gross Monthly:</span>
                <span className="text-base font-bold text-slate-900 font-mono">₹{s.grossMonthly.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-baseline border-b border-slate-100 pb-2">
                <span className="text-xs text-slate-500">Annual CTC:</span>
                <span className="text-sm font-semibold text-indigo-700 font-mono">₹{s.ctcAnnual.toLocaleString()}</span>
              </div>
              <div className="space-y-1.5 pt-1 text-xs">
                {s.items.map((item, idx) => (
                  <div key={idx} className="flex justify-between text-slate-600">
                    <span>{item.componentName}</span>
                    <span className="font-mono font-medium">₹{item.amountMonthly.toLocaleString()}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Payslip Modal */}
      <PayslipModal
        item={selectedPayslipItem}
        periodLabel={latestRun?.periodLabel || 'September 2026'}
        isOpen={!!selectedPayslipItem}
        onClose={() => setSelectedPayslipItem(null)}
      />

      {/* Process Payroll Modal */}
      <ProcessPayrollModal
        isOpen={isProcessModalOpen}
        onClose={() => setIsProcessModalOpen(false)}
        onFinalized={() => {
          // Handled via state update
        }}
      />

      {/* Disburse Modal */}
      {disburseRunId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-xl border border-slate-200 space-y-4 text-xs">
            <h4 className="text-base font-bold text-slate-900">Record Salary Disbursement</h4>
            <p className="text-slate-600">
              Enter the bank transaction reference (NEFT / RTGS / UTR number) for auditing.
            </p>
            <div>
              <label className="block text-slate-600 font-medium mb-1">Payment Reference / UTR *</label>
              <input
                type="text"
                value={disburseRef}
                onChange={(e) => setDisburseRef(e.target.value)}
                placeholder="e.g. UTR-HDFC-99887766"
                className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg font-mono uppercase"
                required
              />
            </div>
            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                onClick={() => setDisburseRunId(null)}
                className="px-3 py-1.5 text-slate-700 bg-white border border-slate-200 rounded-lg"
              >
                Cancel
              </button>
              <button
                onClick={handleDisburseConfirm}
                className="px-4 py-1.5 font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg"
              >
                Confirm & Mark Disbursed
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
